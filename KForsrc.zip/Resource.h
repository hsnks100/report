//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by KFormula.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_KFORMULA_DIALOG             102
#define IDD_ALLOCVARDLG                 103
#define IDD_DRAWGRAPH                   104
#define IDR_MAINFRAME                   128
#define IDR_MENU                        129
#define IDR_MENU1                       130
#define IDR_GRAPHMENU                   130
#define IDC_BTNRESULT                   1000
#define IDC_BTNCLEARFOR                 1001
#define IDC_BTNCLEARRESULT              1002
#define IDC_BTNOPEN                     1003
#define IDC_BTNCLOSE                    1004
#define IDC_BTNMOD                      1005
#define IDC_BTNADD                      1006
#define IDC_BTNMULTI                    1007
#define IDC_BTNDIVIDE                   1008
#define IDC_BTN7                        1009
#define IDC_BTN8                        1010
#define IDC_BTN9                        1011
#define IDC_BTN4                        1012
#define IDC_BTN5                        1013
#define IDC_BTN6                        1014
#define IDC_BTN1                        1015
#define IDC_BTN2                        1016
#define IDC_BTN3                        1017
#define IDC_BTN0                        1018
#define IDC_BUTTON20                    1019
#define IDC_BUTTON21                    1020
#define IDC_BTNEXP                      1021
#define IDC_BTNLOG10                    1022
#define IDC_BTNSIN                      1023
#define IDC_BTNTAN                      1024
#define IDC_BTNCOS                      1025
#define IDC_BTNLOG                      1026
#define IDC_BTN_COSEC                   1027
#define IDC_BTNSEC                      1028
#define IDC_BTNCOT                      1029
#define IDC_BTNFACT                     1030
#define IDC_IPINPUT                     1031
#define IDC_IPRESULT                    1032
#define IDC_BTNSUB                      1033
#define IDC_VARA                        1034
#define IDC_VARB                        1035
#define IDC_BTNPOW                      1035
#define IDC_VARC                        1036
#define IDC_VARD                        1037
#define IDC_VARE                        1038
#define IDC_VARF                        1041
#define IDC_VARG                        1042
#define IDC_VARH                        1043
#define ID_CLIPBOARD                    32771
#define ID_Menu                         32772
#define ID_CLIPBOARD_COPY               32774
#define ID_ALLOCVAR                     32777
#define ID_CLIPBOARD_PASTE              32778
#define ID_GRAPH                        32780
#define ID_ZOOMIN                       32783
#define ID_ZOOMOUT                      32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
