// AllocVarDlg.cpp : ���� �����Դϴ�.
//
/* Programmed by 21132 �Ѱ�� *******************/
/* msn : hsnks100@hotmail.com, http://zsoo.net */
#include "stdafx.h"
#include "KFormula.h"
#include ".\allocvardlg.h"

#include <winuser.h>

namespace global
{
	extern CFormulaParser parser;
}


// AllocVarDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(AllocVarDlg, CDialog)
AllocVarDlg::AllocVarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(AllocVarDlg::IDD, pParent)
	, var_a(_T(""))
	, var_b(_T(""))
	, var_c(_T(""))
	, var_d(_T(""))
	, var_e(_T(""))
	, var_f(_T(""))
	, var_g(_T(""))
	, var_h(_T(""))
//	, var_x(_T(""))
{
}

AllocVarDlg::~AllocVarDlg()
{
}

void AllocVarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_VARA, var_a);
	DDX_Text(pDX, IDC_VARB, var_b);
	DDX_Text(pDX, IDC_VARC, var_c);
	DDX_Text(pDX, IDC_VARD, var_d);
	DDX_Text(pDX, IDC_VARE, var_e);
	DDX_Text(pDX, IDC_VARF, var_f);
	DDX_Text(pDX, IDC_VARG, var_g);
	DDX_Text(pDX, IDC_VARH, var_h);
//	DDX_Text(pDX, IDC_VARX, var_x);
}


BEGIN_MESSAGE_MAP(AllocVarDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
//	ON_WM_ACTIVATE()
ON_WM_SETFOCUS()
END_MESSAGE_MAP()


// AllocVarDlg �޽��� ó�����Դϴ�.

void AllocVarDlg::OnBnClickedOk()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	UpdateData(1);
	global::parser.SetFunctConst(1, RationalNumber((const char*)var_a));
	global::parser.SetFunctConst(2, RationalNumber((const char*)var_b));
	global::parser.SetFunctConst(3, RationalNumber((const char*)var_c));
	global::parser.SetFunctConst(4, RationalNumber((const char*)var_d));
	global::parser.SetFunctConst(5, RationalNumber((const char*)var_e));
	global::parser.SetFunctConst(6, RationalNumber((const char*)var_f));
	global::parser.SetFunctConst(7, RationalNumber((const char*)var_g));
	global::parser.SetFunctConst(8, RationalNumber((const char*)var_h));
	//parser.SetFunctConst(1, RationalNumber((const char*)var_a));
	OnOK();
}

//void AllocVarDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
//{
//	CDialog::OnActivate(nState, pWndOther, bMinimized);
//	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
//}

BOOL AllocVarDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	UpdateData(0);
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void AllocVarDlg::OnSetFocus(CWnd* pOldWnd)
{
	CDialog::OnSetFocus(pOldWnd);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if (pOldWnd->GetSafeHwnd()) 
		pOldWnd->SetFocus();
}
