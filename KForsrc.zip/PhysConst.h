/* Programmed by 21132 �Ѱ�� ************************************/
/* msn : hsnks100@hotmail.com, http://zsoo.net*******************/
/* �� �ҽ��� Ralf Wirtz ���� �ҽ��� �� ȯ�濡 �°� ������ ���Դϴ�.	*/
//////////////////////////////////////////////////////////////////////
// PhysConst.h: Schnittstelle f? die Klasse CPhysConst.
// Header file based on Physical Constants (p.1233) of RPP
// * T. M. Sanders(sanders@umich.edu) 1/95
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHYSCONST_H__4F565065_8723_477F_B9A6_7F801C4EEC7C__INCLUDED_)
#define AFX_PHYSCONST_H__4F565065_8723_477F_B9A6_7F801C4EEC7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef _DEBUG
// Velocity of light in vacuum (def) m/s		
const RationalNumber _c = RationalNumber("299792458");

// Planck constant (40)J s                 
//const RationalNumber _h = RationalNumber("6.6260755")
//						/(RationalNumber("10").Pow("34"));
const RationalNumber _h = RationalNumber("0.00000000000000000000"
										"000000000000066260755");

// Planck constant, reduced (63) J s       
//const RationalNumber _h_BAR = RationalNumber("1.05457266")
//					/(RationalNumber("10").Pow("34"));
const RationalNumber _h_BAR = RationalNumber("0.00000000000000000000"
											"0000000000000105457266");

// Planck constant, reduced (20) MeV s       
//const RationalNumber _h_BAR_MeVs = RationalNumber("6.5821220")
//							/RationalNumber("10").Pow("22");
const RationalNumber _h_BAR_MeVs = RationalNumber("0.0000000000000000000006582122");

// electron charge magnitude (49) C      
//const RationalNumber _e_C = RationalNumber("1.60217733")
//					/(RationalNumber("10").Pow("19"));
const RationalNumber _e_C = RationalNumber("0.000000000000000000160217733");
// electron charge magnitude (15) esu      
//const RationalNumber _e_ESU = RationalNumber("4.8032068")
//					/(RationalNumber("10").Pow("10"));
const RationalNumber _e_ESU = RationalNumber("0.00000000048032068");

// conversion constant hbar*c (59) MeV Fm            
const RationalNumber _hBARc = RationalNumber("197.327053");

// conversion constant (hbar*c)^2 (23) GeV^2 mbarn            
const RationalNumber _hBARc2 = RationalNumber("0.38937966");

// electron mass (54) kg                  
//const RationalNumber _m_e_kg = RationalNumber("9.1093897")
//						/(RationalNumber("10").Pow("31"));
const RationalNumber _m_e_kg = RationalNumber("0.0000000000000000000"
											  "0000000000091093897");
// electron mass (15) MeV/c^2                   
const RationalNumber _m_e_MeV = RationalNumber("0.51099906");

// proton mass (28) MeV/c^2                     
const RationalNumber _m_P_MeV = RationalNumber("938.27231");

// proton mass (12) u                    
const RationalNumber _m_P_u = RationalNumber("1.007276470");

// proton mass (10) kg                    
//const RationalNumber _m_P_kg = RationalNumber("1.6726231")
//						/(RationalNumber("10").Pow("27"));
const RationalNumber _m_P_kg = RationalNumber("0.0000000000000000000000000016726231");
// proton mass (37) m_e                    
const RationalNumber _m_P_M_E = RationalNumber("1836.152701");

// deuteron mass (57) MeV/c^2                  
const RationalNumber _m_D_MeV = RationalNumber("1875.61339");

// unified atomic mass unit (u) (28) MeV/c^2   
const RationalNumber _u_MeV = RationalNumber("931.49432");

// unified atomic mass unit (u) (10) kg   
//const RationalNumber _u_kg = RationalNumber("1.6605402")
//					/(RationalNumber("10").Pow("27"));
const RationalNumber _u_kg = RationalNumber("0.0000000000000000000000000016605402");
// permittivity of free space F/m      
//const RationalNumber _EPS_0 = RationalNumber("8.854187817")
//						/(RationalNumber("10").Pow("12"));
const RationalNumber _EPS_0 = RationalNumber("0.000000000008854187817");
// permeability of free space N/A^2      
//const RationalNumber _MU_0 = RationalNumber("12.566370614")
//					/(RationalNumber("10").Pow("7"));
const RationalNumber _MU_0 = RationalNumber("0.0000012566370614");
// fine-structure constant (61)        
const RationalNumber _Alpha = RationalNumber("1")/RationalNumber("137.0359895");

// classical electron radius (38) m     
//const RationalNumber _r_e = RationalNumber("2.81794092")
//					/(RationalNumber("10").Pow("15"));
const RationalNumber _r_e = RationalNumber("0.00000000000000281794092");
// electron Compton wavelength (35) m   
//const RationalNumber _LAMBDA_BAR_e = RationalNumber("3.86159323")
//							/(RationalNumber("10").Pow("13"));
const RationalNumber _LAMBDA_BAR_e = RationalNumber("0.000000000000386159323");
// Bohr radius (mnucleus= infty) (24) m     
//const RationalNumber _a_0 = RationalNumber("0.529177249")
//					/(RationalNumber("10").Pow("10"));
const RationalNumber _a_0 = RationalNumber("0.0000000000529177249");

// wavelength of 1 eV/c particle (37) m   
//const RationalNumber _LAMBDA_1EV = RationalNumber("1.23984244")
//							/(RationalNumber("10").Pow("6"));
const RationalNumber _LAMBDA_1EV = RationalNumber("0.00000123984244");
// Rydberg energy (mnucleus = infinity) (40) eV                 
const RationalNumber _R_INF_EV = RationalNumber("13.6056981");

// Thomson cross section (18) barn          
const RationalNumber _SIGMA_0_BARN = RationalNumber("0.66524616");

// Bohr magneton (52)  MeV/T                 
//const RationalNumber _MU_B_MeV_T = RationalNumber("5.78838263")
//							/(RationalNumber("10").Pow("11"));
const RationalNumber _MU_B_MeV_T = RationalNumber("0.0000000000578838263");
// nuclear magneton (28) MeV/T               
//const RationalNumber _MU_N_MeV_T = RationalNumber("3.15245166")
//							/(RationalNumber("10").Pow("14"));
const RationalNumber _MU_N_MeV_T = RationalNumber("0.0000000000000315245166");
// electron cyclotron freq./field (53) C/kg (rad/sT) 
const RationalNumber _E_M_e = RationalNumber("175881962000");

// proton cyclotron freq./field (29) C/kg (rad/sT) 
const RationalNumber _E_M_P = RationalNumber("95788309");

// gravitational constant (85) m^3/kgs^2         
const RationalNumber _G_SI = RationalNumber("0.0000000000667259");

// gravitational constant (86) h_bar c (GeV/c^2)^{-2}       
//const RationalNumber _G_P = RationalNumber("6.70711")
//					/(RationalNumber("10").Pow("39"));
const RationalNumber _G_P = RationalNumber("0.0000000000000000000"
										   "00000000000000000006.70711");
// standard grav. accel., sea level m/s^2 
const RationalNumber _g = RationalNumber("9.80665");

// Avogadro constant (36)  /mole            
//const RationalNumber _N_A = RationalNumber("6.0221367")
//					/(RationalNumber("10").Pow("23"));
const RationalNumber _N_A = RationalNumber("0.000000000000000000000060221367");
// Boltzmann constant (12) J/K             
const RationalNumber _K_B = RationalNumber("0.00000000000000000000001380658");

// Boltzmann constant (73) eV/K            
const RationalNumber _K_B_EV = RationalNumber("0.00008617385");

// molar volume, ideal gas at STP (19) m^3/mole  
const RationalNumber _V_MOLAR = RationalNumber("0.0224141");

// Wien displacement law constant (24) m K 
const RationalNumber _LAMBDAT = RationalNumber("0.002897756");

// Stefan-Boltzmann constant (19) W/m^2K^4       
const RationalNumber _SIGMA_SB = RationalNumber("0.0000000567051");

// Fermi coupling constant (2)  GeV^{-2}        
const RationalNumber _G_F = RationalNumber("0.0000116639");

// weak mixing angle  (5)  at M_Z           
const RationalNumber _SIN2_THETA_W = RationalNumber("0.23192");

// W boson mass (26) GeV/c^2                  
const RationalNumber _M_W = RationalNumber("80.22");

// Z_0 boson mass (7) GeV/c^2                  
const RationalNumber _M_Z0 = RationalNumber("91.187");

// strong coupling constant (5))  at M_Z     
const RationalNumber _G_S = RationalNumber("0.117");
#endif

class CPhysConst  
{
public:
	CPhysConst();
	virtual ~CPhysConst();

public:
	//Functions
	BOOL IsPhysConst(CString str);
	RationalNumber GetPhysConstValue(const CString str);
	CString GetEachPhysConst(int i);
	void SetPhysConstOrder();

private:
	// String Array
	CStringArray m_strPhysConst;
};

#endif // !defined(AFX_PHYSCONST_H__4F565065_8723_477F_B9A6_7F801C4EEC7C__INCLUDED_)
