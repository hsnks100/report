/* Programmed by 21132 �Ѱ�� ************************************/
/* msn : hsnks100@hotmail.com, http://zsoo.net*******************/
/* �� �ҽ��� Ralf Wirtz ���� �ҽ��� �� ȯ�濡 �°� ������ ���Դϴ�.	*/

//////////////////////////////////////////////////////////////////////
// FormulaParser.cpp: implementation of the CFormulaParser class.
// Copyright: 2004, Ralf Wirtz
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>
//#include "parser.h"
#include "FormelParser.h"
//#include "basis.h"
//#include "String_VC6.h"
#include <FLOAT.H>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CString CFormulaParser::g_strF = _T("");

//#define PI				3.1415926535897932384626433832795


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFormulaParser::CFormulaParser()
{	
	m_strStandardFunction.Add("");
	m_strStandardFunction.Add("PI");
	m_strStandardFunction.Add("ABS");
	m_strStandardFunction.Add("SQRT");
	m_strStandardFunction.Add("SINH");
	m_strStandardFunction.Add("COSH");
	m_strStandardFunction.Add("TANH");
	m_strStandardFunction.Add("ARCTAN");
	m_strStandardFunction.Add("LN");
	m_strStandardFunction.Add("LOG");
	m_strStandardFunction.Add("EXP");
	m_strStandardFunction.Add("SIN"); //mu?in der Reihenfolge nach SINH stehen!!!
	m_strStandardFunction.Add("COS");
	m_strStandardFunction.Add("TAN");
	m_strStandardFunction.Add("COT");
	m_strStandardFunction.Add("ARCSIN");
	m_strStandardFunction.Add("ARCCOS");
	m_strStandardFunction.Add("INT");
	m_strStandardFunction.Add("RAD");
	m_strStandardFunction.Add("DEG");
	m_strStandardFunction.Add("SIGN");
	m_strStandardFunction.Add("ARSINH");
	m_strStandardFunction.Add("ARCOSH");
	m_strStandardFunction.Add("ARTANH");
	m_strStandardFunction.Add("KGV");
	m_strStandardFunction.Add("GGT");
	m_strStandardFunction.Add("FACT");
	m_strStandardFunction.Add("CSC");
	m_strStandardFunction.Add("SEC");
	CString str;
	for (int i = 1; i < 100; i++)
	{
		str = m_PhysConst.GetEachPhysConst(i);
		if (str == "***") break;
		m_strStandardFunction.Add(str);
	}
}

CFormulaParser::~CFormulaParser()
{

}

//////////////////////////////////////////////////////////////////////
// Methoden
//////////////////////////////////////////////////////////////////////

RationalNumber CFormulaParser::SignFactor(int& nPosition, CString& strCharacter)
{
	if (strCharacter == "-")
	{
		Char_n(nPosition, strCharacter);
		return RationalNumber("-1") * Factor(nPosition, strCharacter);
	}
	else return Factor(nPosition, strCharacter);
}

void CFormulaParser::StripFormula(CString& strFormula)
{
	int Level = 0;

	if (strFormula.GetLength() < 1) return;
	//	TRACE("Formel vorher: %s\n", strFormula);

	// Kommas durch Punkte ersetzen, alles runde Klammern
	strFormula.Replace(_T(" "), _T(""));
	strFormula.Replace(_T(","), _T("."));
	strFormula.Replace(_T("["), _T("("));
	strFormula.Replace(_T("]"), _T(")"));
	strFormula.Replace(_T("{"), _T("("));
	strFormula.Replace(_T("}"), _T(")"));

	strFormula.Replace(_T("*(1)"),_T(""));
	strFormula.Replace(_T("(1)*"),_T(""));

	strFormula.Replace(_T("*(x)"),_T("*x"));
	// geht nicht wegen sin(x)* strFormula.Replace(_T("(x)*"),_T("x*"));
	strFormula.Replace(_T("((x)*"),_T("(x*"));
	strFormula.Replace(_T("+(x)*"),_T("+x*"));
	strFormula.Replace(_T("-(x)*"),_T("-x*"));
	strFormula.Replace(_T("*(x)*"),_T("*x*"));
	strFormula.Replace(_T("(sin(x))"),_T("sin(x)"));
	strFormula.Replace(_T("(cos(x))"),_T("cos(x)"));
	strFormula.Replace(_T("(cot(x))"),_T("cot(x)"));
	strFormula.Replace(_T("(tan(x))"),_T("tan(x)"));
	strFormula.Replace(_T("(exp(x))"),_T("exp(x)"));
	strFormula.Replace(_T("(log(x))"),_T("log(x)"));
	strFormula.Replace(_T("(ln(x))"),_T("ln(x)"));

	// Einschlie?nde Klammern beseitigen
	for (int i = 0; i < strFormula.GetLength(); i++)
	{
		switch (strFormula[i])
		{
		case '(': Level++; continue;
		case ')': Level--; continue;
		}
		if (Level == 0 && i < strFormula.GetLength() - 1)
		{
			Level = -1; // Markierung
			break;
		}
	}

	if (Level != -1)
	{
		while (strFormula[0] == '(' && strFormula[strFormula.GetLength() - 1] == ')')
		{
			strFormula = strFormula.Mid(1, strFormula.GetLength() - 2);
		}
	}

	// F?rende und abschlie?nde Leerzeichen und positive Vorzeichen entfernen
	while (strFormula[0]=='+' || strFormula[0]==' ') 
	{
		strFormula = strFormula.Mid(1);
	}
	strFormula.TrimRight();

	//Alle unn?igen Klammern beseitigen
	int Pos[1000];
	int j = 0;
	Level = 0;
	int l = strFormula.GetLength();

	for (int i = 0; i < l; i++)
	{
		if (strFormula[i] == '(')
		{
			if (i == 0 || (i > 0 && (strFormula[i-1] == '(' || strFormula[__min(i+1,l-1)] == '(')))
			{
				Level++;
				Pos[++j] = i;
			}
		}
		else if (strFormula[i] == ')')
		{
			Level--;
			if (Level > 0 && strFormula[i+1] == ')')
			{
				//rechte Klammer
				CString left = strFormula.Left(i);
				CString mid = strFormula.Mid(i+1);
				strFormula = left + "|" + mid;

				//linke Klammer
				left = strFormula.Left(Pos[Level] + 1);
				mid = strFormula.Mid(Pos[Level+1] + 1);
				strFormula = left + "|" + mid;

				j = 0;
			}
		}
	}
	strFormula.Replace(_T("|"), _T(""));
	//TRACE("Formel nachher: %s\n", strFormula);
}

RationalNumber CFormulaParser::Calculation(CString strFormula, RationalNumber xValue, int& ErrorPosition, CString& Errortext, BOOL strip)
{
	int nPosition;
	CString strCharacter;
	RationalNumber	ergebnis;
	char buffer[32];

	if (strFormula.GetLength() < 1) return RationalNumber("0");

	m_strErrortext.Empty();

	try
	{
		if (strip) StripFormula(strFormula);
		m_strFunction = strFormula;
		m_dFktValue = xValue;
		if (m_dFktValue == RationalNumber("0"))	
		{
			char buf[1000];
			sprintf(buf, "%lf", FLT_MIN);
			m_dFktValue = buf;
		}
		nPosition = 0;
		Char_n(nPosition, strCharacter);

		ergebnis = Expression(nPosition, strCharacter);

		if (strCharacter == strChar_(0))
		{
			Errortext = m_strErrortext;
			ErrorPosition = 0;
		}
		else
		{
			ErrorPosition = nPosition;
			sprintf(buffer, "Error found on position %d!", (int) ErrorPosition);
			Errortext = buffer;
			Errortext += m_strErrortext;
		}

		return ergebnis;
	}
	catch (CException* ex)
	{
		TCHAR szCause[255];        
		ex->GetErrorMessage(szCause, 255);
		Errortext = _T("System Error: ");
		Errortext += szCause;        
		return RationalNumber("0");
	}
}

RationalNumber CFormulaParser::Expression(int& nPosition, CString& strCharacter)
{
	CString strOperator;
	RationalNumber erg = SimpleExpression(nPosition, strCharacter);
	while (strCharacter == "+" || strCharacter == "-")
	{
		strOperator = strCharacter;
		Char_n(nPosition, strCharacter);
		if (strOperator == "+")
			erg += SimpleExpression(nPosition, strCharacter);
		else if (strOperator == "-")
			erg -= SimpleExpression(nPosition, strCharacter);
	}
	return erg;
}

RationalNumber CFormulaParser::SimpleExpression(int& nPosition, CString& strCharacter)
{
	RationalNumber s,dum;
	CString strOperator;
	s = Term(nPosition, strCharacter);
	while (strCharacter == "*" || strCharacter == "/"
		|| strCharacter == "%")
	{
		strOperator = strCharacter;
		Char_n(nPosition, strCharacter);
		if (strOperator == "*")
			s = s * Term(nPosition, strCharacter);
		else if (strOperator == "%")
		{
			dum = Term(nPosition, strCharacter);
			if(dum != RationalNumber("0"))
				s = s % dum;
			else
				m_strErrortext = " Divide by zero!";
		}
		else if (strOperator == "/") 
		{
			dum = Term(nPosition, strCharacter);
			if (dum != RationalNumber("0"))  
				s = s / dum;
			else
				m_strErrortext = " Divide by zero!";
		}  
	}
	return s;
}

RationalNumber CFormulaParser::Term(int& nPosition, CString& strCharacter)
{
	RationalNumber t,vz;
	t = SignFactor(nPosition, strCharacter);
	while (strCharacter == "^")
	{
		Char_n(nPosition, strCharacter);
		vz = SignFactor(nPosition, strCharacter);

		if ((t <= RationalNumber("0") && vz.Abs() <= RationalNumber("1")) || (t <= RationalNumber("0") && vz != vz.ToIntegral()))
			m_strErrortext = " No SQRT from neg. values!";
		else 
			//t = pow(t,vz);		
			t = t.Pow(vz);
	}
	return t;
}

RationalNumber CFormulaParser::Char_n(int& nPosition, CString& strCharacter)
{
	do
	{
		nPosition ++;	// evtl. nach strCharacter
		if (nPosition <= m_strFunction.GetLength())
			//war ge?dert auf:  strCharacter = MID(m_strFunction, nPosition, 1);
			strCharacter = m_strFunction.Mid(nPosition - 1, 1);			
		else 
			strCharacter = strChar_(0);

		//	TRACE("strCharacter= "+ strCharacter);
	}
	while (strCharacter == " "); 

	char buf[1000];
	itoa(nPosition, buf, 10);
	return RationalNumber(buf);
}

void CFormulaParser::SetFormula(CString Formula)
{
	m_strFormula = Formula;
}

CString CFormulaParser::GetFormula()
{
	return m_strFormula;
}

RationalNumber CFormulaParser::Factor(int& nPosition, CString& strCharacter)
{
	RationalNumber f = RationalNumber("0");
	int wI = 0, wL = 0, wBeginn = 0, wError = 0;

	if	(strCharacter == strChar_(0)) return RationalNumber("0");

	if (strCharacter >= "0" && strCharacter <= "9" || strCharacter == ".")
	{
		wBeginn = nPosition;

		do
		{
			Char_n(nPosition, strCharacter);
		} 
		while ((strCharacter >= "0" && strCharacter <= "9" || strCharacter == "."));

		if (strCharacter == ".")
		{
			do
			{
				Char_n(nPosition, strCharacter);
			} 
			while (!(((BYTE)strCharacter[0] >= (BYTE)"0") && ((BYTE)strCharacter[0] <=  (BYTE)"9")  || ((BYTE)strCharacter[0] == (BYTE)".")));
		}
		g_strF = m_strFunction.Mid(wBeginn - 1, nPosition - wBeginn);
		f = (const char*)g_strF;
	} 
	else
	{
		CString strCharacterUpper = strCharacter;
		strCharacterUpper.MakeUpper();
		if (strCharacter == "(")
		{
			Char_n(nPosition, strCharacter);
			f = Expression(nPosition, strCharacter);
			if (strCharacter == ")")
				Char_n(nPosition, strCharacter);
		}
		else if (strCharacterUpper == "X")
		{
			Char_n(nPosition, strCharacter);
			f = m_dFktValue;
		}
		else
		{
			BOOL gefunden = false;
			int AnzStdFunctions = (int)m_strStandardFunction.GetSize() - 1;
			for (wI = 1; wI <= AnzStdFunctions; wI++)
			{
				wL = m_strStandardFunction[wI].GetLength();
				CString strFunktionUpper = m_strFunction.Mid(nPosition - 1, wL);
				strFunktionUpper.MakeUpper();
				CString strDummy(m_strStandardFunction[wI]);
				strDummy.MakeUpper();
				if (strFunktionUpper == strDummy)
				{
					gefunden = true;
					nPosition = nPosition + wL - 1;
					Char_n(nPosition, strCharacter);
					//! Rekursion !!!!!!!!!!!!!!!!!!!!!!
					f = Factor(nPosition, strCharacter);
					//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
					if (strFunktionUpper == "ABS")
						f = f.Abs();
					else if (strFunktionUpper == "SQRT")
						if (f >= RationalNumber("0"))
							f = KfFunction::sqrt(f); // mmojz
					//f = f;
						else
							wError = -1;
					else if (strFunktionUpper == "SINH")
						f = KfFunction::sinh(f);
					//f = f;
					else if (strFunktionUpper == "COSH")
						f = KfFunction::cosh(f);
					//f = f;
					else if (strFunktionUpper == "TANH")
						f = KfFunction::tanh(f);
					else if (strFunktionUpper == "ARCTAN")
						f = KfFunction::atan(f);
					//f = f;
					else if (strFunktionUpper == "LN")
					{
						if (f >= RationalNumber("0")) // mmojz
							f = KfFunction::log(f);
						//f = f;
						else
							wError = -1;
					}
					else if (strFunktionUpper == "LOG")
					{
						if (f >= RationalNumber("0"))
							f = KfFunction::log10(f);
						//f = f;
						else
							wError = -1;
					}
					else if (strFunktionUpper == "EXP")
					{
						if (f <= RationalNumber("41"))
							f = KfFunction::exp(f);
						//f = f;
						else
							wError = -1;
					}
					else if (strFunktionUpper == "SIN")
						f = KfFunction::sin(f);
					else if (strFunktionUpper == "COS")
						f = KfFunction::cos(f);
					else if (strFunktionUpper == "TAN")
					{
						if (KfFunction::cos(f) != RationalNumber("0"))
							f = KfFunction::tan(f);
						else 
							wError = -1;
					}
					else if (strFunktionUpper == "CSC")
					{
						if(KfFunction::sin(f) != RationalNumber("0"))
						{
							f = RationalNumber("1")/KfFunction::sin(f);
						}
						else
							wError = -1;
					}
					else if (strFunktionUpper == "SEC")
					{
						if(KfFunction::cos(f) != RationalNumber("0"))
						{
							f = RationalNumber("1")/KfFunction::cos(f);
						}
						else
							wError = -1;
					}
					else if (strFunktionUpper == "COT")
					{
						if(KfFunction::sin(f) != RationalNumber("0"))
						{
							f = RationalNumber("1")/KfFunction::tan(f);
						}
						else
							wError = -1;
					}
					else if (strFunktionUpper == "ARCSIN")
					{
						if (f.Abs() < RationalNumber("1")) 
							f = KfFunction::asin(f);
						else
							wError = -1;
					}
					else if (strFunktionUpper == "ARCCOS")
					{
						if (f.Abs() <= RationalNumber("1"))
							f = KfFunction::acos(f);
						else 
							wError = -1;
					}
					else if (strFunktionUpper == "INT") 
						f = f.ToIntegral();
					else if (strFunktionUpper == "SIGN") 
						f = KfFunction::signl(f);
					else if (strFunktionUpper == "PI") 
						//f = RationalNumber("3.1415926535897932384626433832795");
						f = RationalNumber("3.14159265");
					else if (strFunktionUpper == "RAD") 
						f = KfFunction::rad(f);
					else if (strFunktionUpper == "DEG") 
						f = KfFunction::deg(f);
					else if (strFunktionUpper == "ARSINH") 
						f = KfFunction::asinh(f);
					else if (strFunktionUpper == "KGV") 
					{
						;
					}
					else if (strFunktionUpper == "GGT") 
					{
						;
					}
					else if (strFunktionUpper == "ARCOSH")
					{
						if (f.Abs() >= RationalNumber("1"))
							f = KfFunction::acosh(f);
						else 
							wError = -1;
					}					
					else if (strFunktionUpper == "ARTANH")
					{
						if (f.Abs() <= RationalNumber("1"))
							f = KfFunction::atanh(f);
						else 
							wError = -1;
					}
					else if(strFunktionUpper == "FACT")
					{
						f = KfFunction::fact(f);
					}
					else 
					{
						RationalNumber pc = m_PhysConst.GetPhysConstValue(strFunktionUpper);
						if (pc  != RationalNumber("0"))
						{
							f = pc;
						}
					}
					break;
				}
			}
			if (!gefunden)
			{
				if (strCharacterUpper >= "A" && strCharacterUpper <= "H")
				{
					Char_n(nPosition, strCharacter);
					BYTE b = BYTE(strCharacterUpper[0]) - 64;
					f = m_dFunctionConstant[b];
				}
			}
		}
	}

	if (wError == -1) 
		m_strErrortext = " General Parser Error blocked!";

	return f;
}

void CFormulaParser::SetFunctConst(int index, RationalNumber val)
{
	if (index >= 1 && index < 10) //zwischen 0 und 9
		m_dFunctionConstant[index] = val;
	else
		AfxMessageBox("ProgrammError in SetFunctConst()");
}

CString CFormulaParser::strChar_(BYTE DecimalZahl)
{
	CString string;
	string.Format("%c", DecimalZahl);
	return string;
}
/*
RationalNumber CFormulaParser::SINQ(RationalNumber Winkel_grad)
{
RationalNumber Winkel_rad = PI * Winkel_grad / 180.0;
return sin(Winkel_rad);
}

RationalNumber CFormulaParser::COSQ(RationalNumber Winkel_grad)
{
// const float PI = 3.141592654f;    
RationalNumber Winkel_rad = PI * Winkel_grad / 180.0;
return cos(Winkel_rad);
}

RationalNumber CFormulaParser::cot(RationalNumber x)
{
return cos(x)/sin(x);
}

RationalNumber CFormulaParser::DEG(RationalNumber x) // rad 
{
// liefert den Winkel eines arithmetischen Ausdrucks im Gradma?
return x * 180.0 / PI;
}

RationalNumber CFormulaParser::RAD(RationalNumber x) // grad
{
// liefert das Bogenma?eines im Gradma?vorliegenden Winkels.
return x * PI / 180.0;
}
*/
CString CFormulaParser::GetNextToken(CString& strSrc, const CString strDelim)
{
	CString token;
	int idx = strSrc.FindOneOf(strDelim);
	if(idx != -1)
	{
		token  = strSrc.Left(idx);
		strSrc = strSrc.Right(strSrc.GetLength() - (idx + 1) );
	}
	else
	{
		token = strSrc;
		strSrc.Empty();
	}
	return token;
}

/*RationalNumber CFormulaParser::signl(RationalNumber x)
{
if (x > 0.0L) return 1.0L;
if (x < 0.0L) return -1.0L;
return 0.0L;
}

RationalNumber CFormulaParser::ArSinh(RationalNumber x)
{
if (x < 0)
return -log(-x + sqrt(sqr(-x) + 1));
return log(x + sqrt(sqr(x) + 1));
}

RationalNumber CFormulaParser::ArCosh(RationalNumber x)
{
return log(x + sqrt(sqr(x) - 1));
}

RationalNumber CFormulaParser::ArTanh(RationalNumber x)
{
return 0.5*logl((1 + x)/ (1 - x));
}

RationalNumber CFormulaParser::ArCoth(RationalNumber x)
{
return 0.5*log((x + 1)/ (x - 1));
}

RationalNumber CFormulaParser::sqr(RationalNumber x)    
{ 
return x*x;
}*/
