/* Programmed by 21132 �Ѱ�� *******************/
/* msn : hsnks100@hotmail.com, http://zsoo.net */

/*	
	�ٽ� �κ��� Core �� ǥ���մϴ�.
	�ٽ� �κ��� �����Ͽ� ������� �Լ����� RefCore �� ǥ���մϴ�.
	public �Լ��� public ǥ�ø� �մϴ�. (�̰� cpp ������)

	�����غ��� // ������ // public // [Core/RefCore] ���°� �ǰڽ��ϴ�.
*/

#ifndef INTEGRALNUMBER_H_
#define INTEGRALNUMBER_H_

#include <vector>
#include <cstring>
#include <string>

namespace in_var
{
	const int SIZE = 1500;
}
class IntegralNumber
{
private:
	std::vector<char> number;
	bool sign; // ����̸� 1, �����̸� 0

public:
	// constructor & destructor
	explicit IntegralNumber(); // Core
	~IntegralNumber();
	IntegralNumber(const IntegralNumber& o); // RefCore
	explicit IntegralNumber(const char* const n); // RefCore

	// operators
	IntegralNumber& operator =(const IntegralNumber& o); // public // Core
	IntegralNumber& operator =(const char* const n); // public // Core
	const IntegralNumber operator +(const IntegralNumber& o) const; // public // Core
	const IntegralNumber operator -(const IntegralNumber& o) const; // public // Core
	const IntegralNumber operator -() const; // public // Core
	const IntegralNumber operator *(const IntegralNumber& o) const; // public // Core
	const IntegralNumber operator /(const IntegralNumber& o) const; // public // Core
	const IntegralNumber operator %(const IntegralNumber& o) const; // public // Core
	IntegralNumber& operator +=(const IntegralNumber& o); // public // RefCore
	IntegralNumber& operator -=(const IntegralNumber& o); // public // RefCore
	IntegralNumber& operator *=(const IntegralNumber& o); // public // RefCore
	IntegralNumber& operator /=(const IntegralNumber& o); // public // RefCore
	IntegralNumber& operator %=(const IntegralNumber& o); // public // RefCore
	const IntegralNumber operator ++(int); // i++; // public // RefCore
	IntegralNumber& operator ++(); // ++i; // public // Core
	const IntegralNumber operator --(int); // i--; // public // RefCore
	IntegralNumber& operator --(); // --i; // Core
	bool operator <(const IntegralNumber& o) const; // public // Core
	bool operator <=(const IntegralNumber& o) const; // public // RefCore
	bool operator >(const IntegralNumber& o) const; // public // RefCore
	bool operator >=(const IntegralNumber& o) const; // public // RefCore
	bool operator ==(const IntegralNumber& o) const; // public // Core
	bool operator !=(const IntegralNumber& o) const; // public // RefCore

	// Functions
	std::string GetNumber() const; // public // Core
	void Swap(IntegralNumber& o); // public // RefCore
	IntegralNumber Abs() const; // public // RefCore
	IntegralNumber Pow(unsigned int n) const; // public // Core
	void SetSign(bool b); // public // Core
};


#endif
