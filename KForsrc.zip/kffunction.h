/* Programmed by 21132 �Ѱ�� ************************************/
/* msn : hsnks100@hotmail.com, http://zsoo.net*******************/
#ifndef KF_FUNCTION_H_
#define KF_FUNCTION_H_

//#define KF_PI 3.1415926535897932384626433832795
namespace KfFunction
{
	RationalNumber sin(const RationalNumber& v);
	RationalNumber cos(const RationalNumber& v);
	RationalNumber tan(const RationalNumber& v);
	//RationalNumber csc(const RationalNumber& v);
	//RationalNumber sec(const RationalNumber& v);
	//RationalNumber cot(const RatioanlNumber& v);
	RationalNumber asin(const RationalNumber& v);
	RationalNumber acos(const RationalNumber& v);
	RationalNumber atan(const RationalNumber& v);
	RationalNumber sinh(const RationalNumber& v);
	RationalNumber cosh(const RationalNumber& v);
	RationalNumber tanh(const RationalNumber& v);
	RationalNumber ceil(const RationalNumber& v);
	RationalNumber abs(const RationalNumber& v);
	RationalNumber floor(const RationalNumber& v);
	RationalNumber log(const RationalNumber& v);
	RationalNumber log10(const RationalNumber& v);
	RationalNumber sqrt(const RationalNumber& v);
	RationalNumber fact(const RationalNumber& v);
	RationalNumber pow(const RationalNumber& v, const RationalNumber& u);	
	RationalNumber exp(const RationalNumber& v);

	RationalNumber deg(const RationalNumber& /* rad */) ;
	RationalNumber rad(const RationalNumber& /* grad */);
	RationalNumber signl(const RationalNumber&);
	RationalNumber asinh(const RationalNumber&);
	RationalNumber acosh(const RationalNumber&);
	RationalNumber atanh(const RationalNumber&);
	RationalNumber acoth(const RationalNumber&);
	RationalNumber sqr(const RationalNumber&);
};

#endif