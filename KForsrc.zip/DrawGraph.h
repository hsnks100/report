#pragma once


// DrawGraph ��ȭ �����Դϴ�.

class DrawGraph : public CDialog
{
	DECLARE_DYNAMIC(DrawGraph)

public:
	DrawGraph(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~DrawGraph();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DRAWGRAPH };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPaint();
private:
	HWND parent;
public:
	void MySetParent(HWND hWnd){parent = hWnd;}
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSize(UINT nType, int cx, int cy);
private:
	int unit;
	int y_scroll;
	int x_scroll;
	POINT pt_start;
	//DWORD down_up_delay;
public:
	afx_msg void OnZoomin();
	afx_msg void OnZoomout();
	virtual BOOL OnInitDialog();
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
public:
	virtual BOOL CreateIndirect(LPCDLGTEMPLATE lpDialogTemplate, CWnd* pParentWnd = NULL, void* lpDialogInit = NULL);
protected:
	virtual void PreInitDialog();
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
};
