#include "stdafx.h"
#include "global.h"

namespace global
{
	extern CFormulaParser parser;
}