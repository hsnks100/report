/* Programmed by 21132 �Ѱ�� *******************/
/* msn : hsnks100@hotmail.com, http://zsoo.net */
#include "stdafx.h"
#include "rationalnumber.h"
IntegralNumber RationalNumber::GetGCD() const // private
{
	// GCD(a, b) = GCD(a-b, b) ���Ǹ� ����
	IntegralNumber a, b;
	a = numerator;
	b = denominator;
	while(b != IntegralNumber("0"))
	{
		a = a % b;
		a.Swap(b);
	}
	return a;
}

RationalNumber::RationalNumber() // public
{
	numerator = "0";
	denominator = "1";
}

RationalNumber::~RationalNumber() // public
{
}

RationalNumber::RationalNumber(const RationalNumber& o) // public
{
	*this = o;
}

RationalNumber::RationalNumber(const char* const n) // public
{
	*this = n;
}

RationalNumber::RationalNumber(const IntegralNumber& num, const IntegralNumber& den) // public
{
	numerator = num;
	denominator = den;
}

RationalNumber::RationalNumber(const std::string& o) // public
{
	*this = o;
}
RationalNumber& RationalNumber::operator =(const std::string& o) // public
{
	*this = o.c_str();
	return *this;
}
RationalNumber& RationalNumber::operator =(const RationalNumber& o) // public
{
	numerator = o.numerator;
	denominator = o.denominator;
	return *this;
}

RationalNumber& RationalNumber::operator =(const char* const n) // public
{
	// a.b ����
	// a ����
	// '.' ���� �ؿ� ������ ������ x �� �ϸ� �и�� 10^x �� ��.
 	if(strlen(n) == 0)
	{
		numerator = "0";
		denominator = "1";
		SetSign(1);
		return *this;
	}
	numerator = "0";
	denominator = "1";
	char _n[in_var::SIZE]; // n ���繰
	bool minus = false;
	char num[in_var::SIZE] = ""; // ����

	strncpy(_n, n, in_var::SIZE-1);
	_n[in_var::SIZE-1] = '\0';
	
	char* pn = _n;
	if(pn[0] == '-')
	{
		minus = true;
		pn++;
	}
	else if(pn[0] == '+')
	{
		pn++;
	}

	char* p = strtok(pn, ".");
	strcat(num, p);

	p = strtok(0, ".");
	if(p)
	{
		strcat(num, p);
		denominator = IntegralNumber("10").Pow((unsigned int)strlen(p));
	}
	else
		denominator = "1";
	numerator = num;
	
	SetSign(!minus);
	return *this;
}


const RationalNumber RationalNumber::operator +(const RationalNumber& o) const // public
{
	RationalNumber ret;
	ret.numerator = (numerator * o.denominator) + (denominator * o.numerator);
	ret.denominator = denominator * o.denominator;

	ret = ret.Abbreviation();	
	return ret;
}

const RationalNumber RationalNumber::operator -(const RationalNumber& o) const // public
{
	RationalNumber oo = o;
	oo.numerator *= IntegralNumber("-1");
	return *this + oo;
}

const RationalNumber RationalNumber::operator -() const // public
{
	RationalNumber oo = *this;
	oo.SetSign( !(oo.GetSign()) );
	return oo;
}

const RationalNumber RationalNumber::operator *(const RationalNumber& o) const // public
{
	RationalNumber ret;
	ret.numerator = numerator * o.numerator;
	ret.denominator = denominator * o.denominator;
	ret = ret.Abbreviation();

	return ret;
}

const RationalNumber RationalNumber::operator /(const RationalNumber& o) const // public
{
	RationalNumber oo = o.Reciprocal();
	return *this * oo;
}

const RationalNumber RationalNumber::operator %(const RationalNumber& o) const // public
{
	/*	0	��	������	����	�Ѵٰ�	�ϸ�								*
	 *	a%b	��	����	|a|%|b|	�̰�,	��ȣ��	a	��	��ȣ��	������.		*
	 ************************************************************************/
	RationalNumber oo = o.Abs();
	RationalNumber _this = Abs();
	RationalNumber ret;
	if(_this < oo)
	{
		ret = _this;
		ret.SetSign(_this.GetSign());
		return ret;
	}
	else
	{
		_this = _this - oo * ((_this / oo).ToIntegral());
		ret = _this;
		ret.SetSign(_this.GetSign());
		return ret;
	}
}
RationalNumber& RationalNumber::operator +=(const RationalNumber& o) // public
{
	*this = *this + o;
	return *this;
}

RationalNumber& RationalNumber::operator -=(const RationalNumber& o) // public
{
	*this = *this - o;
	return *this;
}
RationalNumber& RationalNumber::operator *=(const RationalNumber& o) // public
{
	*this = *this * o;
	return *this;
}
RationalNumber& RationalNumber::operator /=(const RationalNumber& o) // public
{
	*this = *this / o;
	return *this;
}

RationalNumber& RationalNumber::operator %=(const RationalNumber& o) // public
{
	*this = *this % o;
	return *this;
}
const RationalNumber RationalNumber::operator ++(int) // public
{
	RationalNumber temp = *this;
	++(*this);
	return temp;
}
RationalNumber& RationalNumber::operator ++() // public
{
	RationalNumber t = RationalNumber("1");
	*this += t;
	return *this;
}
const RationalNumber RationalNumber::operator --(int) // public
{
	RationalNumber temp = *this;
	--(*this);
	return temp;
}
RationalNumber& RationalNumber::operator --() // public
{
	RationalNumber t = RationalNumber("1");
	*this -= t;
	return *this;
}

bool RationalNumber::operator <(const RationalNumber& o) const // public
{
	RationalNumber a, b;
	bool a_sign, b_sign;
	a = *this;
	b = o;
	if(a.GetSign())
	{
		a_sign = true;
		a.numerator.SetSign(1);
		a.denominator.SetSign(1);
	}
	else
	{
		a_sign = false;
		a.numerator.SetSign(0);
		a.denominator.SetSign(1);
	}

	if(b.GetSign())
	{
		b_sign = true;
		b.numerator.SetSign(1);
		b.denominator.SetSign(1);
	}
	else
	{
		b_sign = false;
		b.numerator.SetSign(0);
		b.denominator.SetSign(1);
	}

	a.numerator = a.numerator * b.denominator;
	b.numerator = b.numerator * a.denominator;
	
	a.numerator.SetSign(a_sign);
	b.numerator.SetSign(b_sign);
	return a.numerator<b.numerator;
}

bool RationalNumber::operator <=(const RationalNumber& o) const // public
{
	return *this == o || *this < o;
}
bool RationalNumber::operator >(const RationalNumber& o) const // public
{
	return !(*this <= o);
}
bool RationalNumber::operator >=(const RationalNumber& o) const // public
{
	return !(*this < o);
}


bool RationalNumber::operator ==(const RationalNumber& o) const // public
{
	if(GetSign() != o.GetSign())
	{
		return false;
	}
	else
	{
		RationalNumber a, b;
		a = this->Abs();
		b = o.Abs();
		a = a.Abbreviation();
		b = b.Abbreviation();
		return a.numerator == b.numerator && a.denominator == b.denominator;
	}
}

bool RationalNumber::operator !=(const RationalNumber& o) const // public
{
	return !(*this == o);
}
std::string RationalNumber::GetNumber() const // public
{
	IntegralNumber quotient;
	IntegralNumber num = numerator.Abs();
	IntegralNumber den = denominator.Abs();
	std::string ret = (num / den).GetNumber();
	num = num % den;

	if(num != IntegralNumber("0"))
		ret += ".";
	
	int limit=31;
	int limit_count=0;
	while(num != IntegralNumber("0"))
	{
		num *= IntegralNumber("10");
		ret += (num / den).GetNumber();
		num = num % den;
		if(limit_count < limit)
			limit_count++;
		else
			break;
	}
	if(!GetSign() && ret != "0")
		ret = std::string("-") + ret;
	return ret;
}

void RationalNumber::Swap(RationalNumber& o) // public
{
	RationalNumber t = o;
	o = *this;
	*this = t;
}

RationalNumber RationalNumber::Abs() const // public
{
	RationalNumber tmp = *this;
	tmp.numerator.SetSign(1);
	tmp.denominator.SetSign(1);
	return *this;
}


RationalNumber RationalNumber::Pow(const RationalNumber& o) const // public
{
	int oo = atoi(o.GetNumber().c_str());
	RationalNumber tmp = RationalNumber("1");
	for(int i=0; i<abs(oo); i++)
	{
		tmp = tmp * (*this);
	}
	if(oo < 0)
	{
		return RationalNumber("1")/tmp;
	}
	else
		return tmp;
	
}


RationalNumber RationalNumber::ToIntegral() const // public
{
	char* t = new char[in_var::SIZE];
	strcpy(t, GetNumber().c_str());
	strtok(t, ".");
	RationalNumber ret = RationalNumber(t);
	ret.SetSign(GetSign());
	delete [] t;
	return ret;
}
void RationalNumber::SetSign(bool b) // public
{
	if(b)
	{
		numerator.SetSign(1);
		denominator.SetSign(1);
	}
	else
	{
		numerator.SetSign(0);
		denominator.SetSign(1);
	}
}

bool RationalNumber::GetSign() const // public
{
	return (numerator * denominator)>=IntegralNumber("0");
}
RationalNumber RationalNumber::Abbreviation() const
{
	RationalNumber ret = *this;
	IntegralNumber GCD = ret.GetGCD();
	ret.numerator /= GCD;
	ret.denominator /= GCD;

	return ret;
}

RationalNumber RationalNumber::Reciprocal() const
{
	RationalNumber ret = *this;
	ret.numerator.Swap(ret.denominator);
	
	return ret;
}