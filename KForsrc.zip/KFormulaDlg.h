/* Programmed by 21132 �Ѱ�� *******************/
/* msn : hsnks100@hotmail.com, http://zsoo.net */

// KFormulaDlg.h : ��� ����
//

#pragma once
#include "AllocVarDlg.h"
#include "DrawGraph.h"
#include "afxwin.h"

// CKFormulaDlg ��ȭ ����
class CKFormulaDlg : public CDialog
{
// ����
public:
	CKFormulaDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_KFORMULA_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����


// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnresult();
private:
	CString formula;
	CString result;
	AllocVarDlg alloc_var_dlg;
	DrawGraph draw_graph_dlg;
	static DWORD WINAPI ResultViewer(LPVOID data);
	HANDLE thread_handle;

	//static bool is_pause;
public:
	afx_msg void OnBnClickedBtnclearfor();
	afx_msg void OnBnClickedBtnclearresult();
	afx_msg void OnBnClickedBtnopen();
	afx_msg void OnBnClickedBtnclose();
	afx_msg void OnBnClickedBtnsin();
	afx_msg void OnBnClickedBtnCosec();
	afx_msg void OnBnClickedBtnadd();
	afx_msg void OnBnClickedBtnmulti();
	afx_msg void OnBnClickedBtncos();
	afx_msg void OnBnClickedBtnsec();
	afx_msg void OnBnClickedBtndivide();
	afx_msg void OnBnClickedBtnmod();
	afx_msg void OnBnClickedBtntan();
	afx_msg void OnBnClickedBtncot();
//	afx_msg void OnBnClickedBtnpow();
	afx_msg void OnBnClickedBtnlog10();
	afx_msg void OnBnClickedBtnlog();
	afx_msg void OnBnClickedBtnfact();
	afx_msg void OnBnClickedBtn7();
	afx_msg void OnBnClickedBtn0();
	afx_msg void OnBnClickedBtn1();
	afx_msg void OnBnClickedBtn2();
	afx_msg void OnBnClickedBtn3();
	afx_msg void OnBnClickedBtn4();
	afx_msg void OnBnClickedBtn5();
	afx_msg void OnBnClickedBtn6();
	afx_msg void OnBnClickedBtn8();
	afx_msg void OnBnClickedBtn9();
	afx_msg void OnBnClickedBtnsub();
	afx_msg void OnClipboardCopy();
	afx_msg void OnClipboardPaste();
	afx_msg void OnAllocvar();
//	afx_msg void OnSetFocus(CWnd* pOldWnd);
//	afx_msg void OnBnSetfocusBtnopen();
//	afx_msg void OnBnKillfocusBtnopen();
	afx_msg void OnBnClickedBtnexp();
	afx_msg void OnBnClickedBtnpow();
	afx_msg void OnGraph();
};
