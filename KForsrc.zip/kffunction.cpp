/* Programmed by 21132 �Ѱ�� ************************************/
/* msn : hsnks100@hotmail.com, http://zsoo.net*******************/
#include "stdafx.h"

RationalNumber KfFunction::sin(const RationalNumber& v)
{
	char* buf = new char[in_var::SIZE];
	if(v >= RationalNumber("0"))
	{
		std::string t = (v%(RationalNumber("3.14159265")*RationalNumber("2"))).GetNumber();
		sprintf(buf, "%lf", ::sin(atof(t.c_str())) );
	}
	else
	{
		// ������--;
		RationalNumber vv = v.Abs();
		std::string t = (vv%(RationalNumber("3.14159265")*RationalNumber("2"))).GetNumber();
		sprintf( buf, "%lf", ::sin(atof(t.c_str())) );
	}
	CString temp = buf;
	delete [] buf;
	return RationalNumber((const char*)temp);
}

RationalNumber KfFunction::cos(const RationalNumber& v)
{
	RationalNumber vv = v.Abs();
	std::string t = (vv%(RationalNumber("3.14159265")*RationalNumber("2"))).GetNumber();
	char* buf = new char[in_var::SIZE];
	sprintf(buf, "%lf", ::cos(atof(t.c_str())) );
	CString temp = buf;
	delete [] buf;
	return RationalNumber((const char*)temp);
}

RationalNumber KfFunction::tan(const RationalNumber& v)
{
	char* buf = new char[in_var::SIZE];
	if(v >= RationalNumber("0"))
	{
		std::string t = (v%(RationalNumber("3.14159265")*RationalNumber("2"))).GetNumber();
		sprintf(buf, "%lf", ::tan(atof(t.c_str())) );
	}
	else
	{
		// ������--;
		RationalNumber vv = v.Abs();
		std::string t = (vv%(RationalNumber("3.14159265")*RationalNumber("2"))).GetNumber();
		sprintf( buf, "%lf", ::tan(atof(t.c_str())) );
	}

	CString temp = buf;
	delete [] buf;
	return RationalNumber((const char*)temp);
}


// ���� ���� �Լ� �Ѥ�;;
RationalNumber KfFunction::asin(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::acos(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::atan(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::sinh(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::cosh(const RationalNumber& v)
{
	return v;
}
RationalNumber KfFunction::tanh(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::ceil(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::abs(const RationalNumber& v)
{
	return v.Abs();
}

RationalNumber KfFunction::floor(const RationalNumber& v)
{
	return v;
}
RationalNumber KfFunction::log(const RationalNumber& v)
{
	return v;
}

/*
* ���� �����̸�... limits.h ����
- INT_MAX, INT_MIN, CHAR_MAX, CHAR_MIN, LONG_MAX, LONG_MIN, ...
- Signed ���� Unsigned ������ �����Ͽ� ���� �Ǿ� ����

* �Ǽ� �����̸�... float.h ����
- FLT_MAX, FLT_MIN, DBL_MAX, DBL_MIN, LDBL_MAX, LDBL_MIN, ... 
*/
RationalNumber KfFunction::log10(const RationalNumber& v)
{
	//std::numeric_
	RationalNumber vv = v;
	char* double_max;
	double_max = new char[2000];
	sprintf(double_max, "%f", 1000000000.0);

	double y;
	if(vv > RationalNumber(double_max))
	{
		int count=0;
		do
		{
			vv = vv/RationalNumber("10");
			count++;
		}while(vv < RationalNumber(double_max));
		y = ::log10(atof(vv.GetNumber().c_str())) + count;
	}
	else
	{
		y = ::log10(atof(vv.GetNumber().c_str()));
	}
	char ret[2000];
	sprintf(ret, "%f", y);
	delete [] double_max;
	return RationalNumber(ret);
}

RationalNumber KfFunction::sqrt(const RationalNumber& v)
{
	return v;
}

RationalNumber KfFunction::pow(const RationalNumber& v, const RationalNumber& u)
{
	return v.Pow(u);
}


RationalNumber KfFunction::fact(const RationalNumber& v)
{
	RationalNumber dv = v;
	RationalNumber temp = RationalNumber("1");
	while(dv >= RationalNumber("1"))
	{
		temp = temp * dv;
		dv--;
	}
	return temp;
}

RationalNumber KfFunction::exp(const RationalNumber& v)
{
	//���� e^v ��
	return RationalNumber("2.7182818284590452353602874713489").Pow(v);
}

RationalNumber KfFunction::deg(const RationalNumber& x /* rad */)
{
	return x;
}

RationalNumber KfFunction::rad(const RationalNumber& x /* grad */)
{
	return x;
}

RationalNumber KfFunction::signl(const RationalNumber& x)
{
	return x;
}

RationalNumber KfFunction::asinh(const RationalNumber& x)
{
	return x;
}

RationalNumber KfFunction::acosh(const RationalNumber& x)
{
	return x;
}

RationalNumber KfFunction::atanh(const RationalNumber& x)
{
	return x;
}

RationalNumber KfFunction::acoth(const RationalNumber& x)
{
	return x;
}

RationalNumber KfFunction::sqr(const RationalNumber& x)
{
	return x*x;
}