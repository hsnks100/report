/* Programmed by 21132 �Ѱ�� ************************************/
/* msn : hsnks100@hotmail.com, http://zsoo.net*******************/
/* �� �ҽ��� Ralf Wirtz ���� �ҽ��� �� ȯ�濡 �°� ������ ���Դϴ�.	*/
//
// FormulaParser.h: interface for the CFormulaParser class.
// Copyright: 2004, Ralf Wirtz
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FORMELPARSER_H__F802A742_8772_11D1_BD24_0000C02FB5AC__INCLUDED_)
#define AFX_FORMELPARSER_H__F802A742_8772_11D1_BD24_0000C02FB5AC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define ANZFUNKTKONST 10

#include "PhysConst.h"

class CFormulaParser  
{
private:

	CPhysConst m_PhysConst; 

	//Implementation
	CString m_strFormula;
	CString m_strFunction;
	CString m_strErrortext;

	static CString g_strF;

	RationalNumber m_dFktValue;
	RationalNumber m_dFunctionConstant[ANZFUNKTKONST];
	CStringArray m_strStandardFunction;

	RationalNumber SignFactor(int& nPosition, CString& strCharacter);
	RationalNumber Expression(int& nPosition, CString& strCharacter);
	RationalNumber SimpleExpression(int& nPosition, CString& strCharacter);
	RationalNumber Term(int& nPosition, CString& strCharacter);
	RationalNumber Factor(int& nPosition, CString& strCharacter);
	RationalNumber Char_n(int& nPosition, CString& strCharacter);
	CString strChar_(BYTE DecimalZahl);

	CString GetNextToken(CString& strSrc, const CString strDelim);
	/*RationalNumber SINQ(RationalNumber Winkel_grad);
	RationalNumber COSQ(RationalNumber Winkel_grad);
	RationalNumber DEG(RationalNumber x ) ; // rad 
	RationalNumber RAD(RationalNumber x ); //  grad 
	RationalNumber cot(RationalNumber x);
	RationalNumber signl(RationalNumber x);
	RationalNumber ArSinh(RationalNumber x);
	RationalNumber ArCosh(RationalNumber x);
	RationalNumber ArTanh(RationalNumber x);
	RationalNumber ArCoth(RationalNumber x);
	RationalNumber sqr(RationalNumber x);*/

public:
	void StripFormula(CString& strFormula);
	CString GetFormula();
	void SetFormula(CString Formula);
	void SetFunctConst(int index, RationalNumber val);
	
	CFormulaParser();
	virtual ~CFormulaParser();

	//Interface
	RationalNumber Calculation(CString strFormula, RationalNumber xValue, int& ErrorPosition, CString& Errortext, BOOL strip = true);
};

#endif // !defined(AFX_FORMELPARSER_H__F802A742_8772_11D1_BD24_0000C02FB5AC__INCLUDED_)
