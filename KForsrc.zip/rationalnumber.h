/* Programmed by 21132 �Ѱ�� *******************/
/* msn : hsnks100@hotmail.com, http://zsoo.net */
#ifndef RATIONALNUMBER_H_
#define RATIONALNUMBER_H_
#include "integralnumber.h"
//#include <cmath>
/*	
	�ٽ� �κ��� Core �� ǥ���մϴ�.
	�ٽ� �κ��� �����Ͽ� ������� �Լ����� RefCore �� ǥ���մϴ�.
	public �Լ��� public ǥ�ø� �մϴ�. (�̰� cpp ������)

	�����غ��� // ������ // public // [Core/RefCore] ���°� �ǰڽ��ϴ�.
*/


class RationalNumber
{
private:
	IntegralNumber numerator; // ����
	IntegralNumber denominator; // �и�

	IntegralNumber GetGCD() const; // ���� �и��� GCD // private // Core // 
public:
	// constructor & destructor
	explicit RationalNumber(); // Core
	~RationalNumber();
	RationalNumber(const RationalNumber& o); // RefCore
	explicit RationalNumber(const IntegralNumber& num, const IntegralNumber& den); // RefCore
	explicit RationalNumber(const char* const n); // RefCore	
	explicit RationalNumber(const std::string& o); // public // RefCore
	// operators
	RationalNumber& operator =(const std::string& o); // public // RefCore
	RationalNumber& operator =(const RationalNumber& o); // public // Core
	RationalNumber& operator =(const char* const n); // public // Core
	const RationalNumber operator +(const RationalNumber& o) const; // public // Core
	const RationalNumber operator -(const RationalNumber& o) const; // public // Core
	const RationalNumber operator -() const; // public // Core
	const RationalNumber operator *(const RationalNumber& o) const; // public // Core
	const RationalNumber operator /(const RationalNumber& o) const; // public // Core
	const RationalNumber operator %(const RationalNumber& o) const; // public // Core
	RationalNumber& operator +=(const RationalNumber& o); // public // RefCore
	RationalNumber& operator -=(const RationalNumber& o); // public // RefCore
	RationalNumber& operator *=(const RationalNumber& o); // public // RefCore
	RationalNumber& operator /=(const RationalNumber& o); // public // RefCore
	RationalNumber& operator %=(const RationalNumber& o); // public // RefCore
	const RationalNumber operator ++(int); // i++; // public // RefCore
	RationalNumber& operator ++(); // ++i; // public // Core
	const RationalNumber operator --(int); // i--; // public // RefCore
	RationalNumber& operator --(); // --i; // public // Core
	bool operator <(const RationalNumber& o) const; // public // Core
	bool operator <=(const RationalNumber& o) const; // public // RefCore
	bool operator >(const RationalNumber& o) const; // public // RefCore
	bool operator >=(const RationalNumber& o) const; // public // RefCore
	bool operator ==(const RationalNumber& o) const; // public // Core
	bool operator !=(const RationalNumber& o) const; // public // RefCore

	// Functions
	std::string GetNumber() const; // public // Core
	void Swap(RationalNumber& o); // public // RefCore
	RationalNumber Abs() const; // public // RefCore
	RationalNumber Pow(const RationalNumber& o) const; // public // RefCore
	RationalNumber ToIntegral() const; // public // RefCore

	void SetSign(bool b); // public // Core
	bool GetSign() const; // public // Core
	RationalNumber Abbreviation() const; // public // Core
	RationalNumber Reciprocal() const; // public // Core
};

#endif