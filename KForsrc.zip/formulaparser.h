/* Programmed by 21132 �Ѱ�� *******************/
/* msn : hsnks100@hotmail.com, http://zsoo.net */
/* �� �ҽ��� ����Դ��� �ҽ��� (����&����)�Ͽ����ϴ�.*/
#ifndef FORMULAPARSER_H_
#define FORMULAPARSER_H_

#include <stack>
#include <vector>
#include <string>
#include <cmath>


namespace formula
{
	const int MAXLEN = 256;
	const int MAXVAR = 26;
}

template <class T>
class FormulaParser
{
private:
	char cur_token[formula::MAXLEN];
	char *cur_pos;
	enum tok_type { Unknown, Function, Variable, Number, Operator, Rel_Op };
	enum rel_op_type{ LT, GT, LE, GE, EQ, NE };
	enum error { Ok, Divide_By_Zero , Rparen_Needed,
		Lparen_Needed, Syntax_Error };
	T var[formula::MAXVAR];
	char* error_msg[5];
	enum error status;
	char* relop_name[7];
	enum tok_type token_type;
	char* func_name[100];
	T (*function[100])(const T&);

	void proc_exp_assign(T* result);
	void proc_exp_relop(T* result);
	void proc_exp_2plus(T* result);
	void proc_exp_2mult(T *result);
	void proc_exp_power(T *result);
	void proc_exp_unary(T *result);
	void proc_exp_paren(T *result);
	void proc_exp_atom(T *result);
public:
	FormulaParser();
	void init_var(void);
	void init_token(char *s);
	error get_status(void);
	int lookup_var(char *s);
	int lookup_func(char *s);
	int get_token(void);
	rel_op_type lookup_relop(char *s);
	const char* print_error(enum error e);
	char *is_white(char c);
	void put_back(void);
	char *is_delim(char c);
	char *is_digit(char c);
	char *is_alpha(char c);
	T get_var(int i);
	T put_var(int i, T d);
	void eval_exp(T *result);
};


template <class T>
FormulaParser<T>::FormulaParser()
{
	error_msg[0] = "Ok";
	error_msg[1] = "Divide By Zero";
	error_msg[2] = "')' is needed";
	error_msg[3] = "'(' is needed";
	error_msg[4] = "Syntax Error";
	status = Ok;
	relop_name[0] = "<";
	relop_name[1] = ">";
	relop_name[2] = "<=";
	relop_name[3] = ">=";
	relop_name[4] = "==";
	relop_name[5] = "!=";
	relop_name[6] = NULL;
	func_name[0] = "sin";
	func_name[1] = "cos";
	func_name[2] = "tan";
	func_name[3] = "asin";
	func_name[4] = "acos";
	func_name[5] = "atan";
	func_name[6] = "sinh";
	func_name[7] = "cosh";
	func_name[8] = "tanh";
	func_name[9] = "ceil";
	func_name[10] = "abs";
	func_name[11] = "floor";
	func_name[12] = "log";
	func_name[13] = "log10";
	func_name[14] = "sqrt";
	func_name[15] = "cosec";
	func_name[16] = "sec";
	func_name[17] = "cot";
	func_name[18] = "fact";
	func_name[19] = NULL;

	function[0] = KfFunction::sin;
	function[1] = KfFunction::cos;
	function[2] = KfFunction::tan;
	function[3] = KfFunction::asin;
	function[4] = KfFunction::acos;
	function[5] = KfFunction::atan;
	function[6] = KfFunction::sinh;
	function[7] = KfFunction::cosh;
	function[8] = KfFunction::tanh;
	function[9] = KfFunction::ceil;
	function[10] = KfFunction::abs;
	function[11] = KfFunction::floor;
	function[12] = KfFunction::log;
	function[13] = KfFunction::log10;
	function[14] = KfFunction::sqrt;
	function[15] = KfFunction::cosec;
	function[16] = KfFunction::sec;
	function[17] = KfFunction::cot;
	function[18] = KfFunction::fact;
	function[19] = 0;

	init_var();
}

template <class T>
typename FormulaParser<T>::error FormulaParser<T>::get_status(void)
{
	error i;
	i = status;
	status = Ok;
	return i;
}

template <class T>
const char* FormulaParser<T>::print_error(enum error e)
{
	return error_msg[e];
}

template <class T>
void FormulaParser<T>::init_var(void)
{
	int i;
	for (i = 0; i < formula::MAXVAR; i++) var[i] = "0";
	var['P'-'A'] = "3.14159265358979323846";
	var['E'-'A'] = "2.7182818284590452354";
}

template <class T>
int FormulaParser<T>::lookup_var(char *s)
{
	if (strlen(s) == 1 && 'A' <= toupper(*s) && toupper(*s) <= 'Z')
		return toupper(*s) - 'A';
	else return -1;
}

template <class T>
T FormulaParser<T>::get_var(int i)
{
	return var[toupper(i) - 'A'];
}


template <class T>
T FormulaParser<T>::put_var(int i, T d)
{
	var[toupper(i) - 'A'] = d;
	return d;
}

template <class T>
int FormulaParser<T>::lookup_func(char *s)
{
	int i;
	for (i = 0; func_name[i] && stricmp(func_name[i], s) != 0; i++);
	if (!func_name[i]) return -1;
	else return i;
}

template <class T>
char* FormulaParser<T>::is_white(char c)
{
	return strchr(" \t\n\r", c);
}

template <class T>
char* FormulaParser<T>::is_delim(char c)
{
	return strchr("+-*^/%=;(),'""!<>&~`@#$\\:?/ []{}|", c);
}

template <class T>
char* FormulaParser<T>::is_digit(char c)
{
	return strchr("0123456789.Ee-+", c);
}

template <class T>
char* FormulaParser<T>::is_alpha(char c)
{
	return strchr("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_", c);
}

template <class T>
void FormulaParser<T>::init_token(char *s)
{
	for(int i=1; i<(int)strlen(s); i++)
	{
		bool d =  s[i] == '+' || s[i] == '-';
		bool d2 = s[i-1] != 'e' && s[i-1] != 'E';
		if(d & d2)
		{
			int j;
			s[strlen(s)+2] = '\0';
			for(j=(int)strlen(s)-1; j>=i+1; j--)
			{
				s[j+2] = s[j];
			}
			
			s[i+1] = s[i];
			s[i] = ' ';
			s[i+2] = ' ';
			i+=2;
		}
	}
	cur_pos = s;
	cur_token[0] = NULL;
}

template <class T>
void FormulaParser<T>::put_back(void)
{
	char *t;
	t = cur_token;
	while (*t++) cur_pos--;
}

template <class T>
int FormulaParser<T>::get_token(void)
{
	int i;
	while (is_white(*cur_pos) && *cur_pos) 
		cur_pos++;

	if (*cur_pos == NULL)
	{
		cur_token[0] = NULL;
		token_type = Unknown;
		return 0;   /* end of line */
	}

	/* check relation operator */
	if (strchr("!<>=", *cur_pos))
	{
		cur_token[0] = *cur_pos++;  /* get first char */
		cur_token[1] = NULL;
		if (*cur_pos == '=')   /*  ==, !=, >=, <=  */
		{
			cur_token[1] = *cur_pos++;
			cur_token[2] = NULL;
		}
		if (strcmp(cur_token, "=") == 0) token_type = Operator;
		else token_type = Rel_Op;
		return 1;
	}
	if (is_delim(*cur_pos))
	{
		cur_token[0] = *cur_pos++;
		cur_token[1] = NULL;
		token_type = Unknown;
		return 1;
	}
	if (is_alpha(*cur_pos))
	{
		i = 0;
		while (!is_delim(*cur_pos))
			cur_token[i++] = *cur_pos++;
		cur_token[i] = NULL;
		if (lookup_var(cur_token) != -1) token_type = Variable;
		else if (lookup_func(cur_token) != -1) token_type = Function;
		else token_type = Unknown;
		return 1;
	}
	if (is_digit(*cur_pos))
	{
		i = 0;
		while (is_digit(*cur_pos))
			cur_token[i++] = *cur_pos++;
		cur_token[i] = NULL;
		token_type = Number;
		return 1;
	}
	return 0;
}


template <class T>
void FormulaParser<T>::eval_exp(T *result)
{

	if (!get_token())
	{
		*result = 0;
		return;
	}
	proc_exp_assign(result);
	put_back();
}

template <class T>
void FormulaParser<T>::proc_exp_assign(T *result)
{
	char temp_token[formula::MAXLEN];
	enum tok_type temp_type;
	int i;
	if (token_type == Variable)
	{
		strcpy(temp_token, cur_token);
		temp_type = token_type;
		i = cur_token[0];
		get_token();
		if (strcmp(cur_token, "=") == 0)   /* if assignment */
		{
			get_token();
			proc_exp_assign(result);
			put_var(i, *result);
			return;
		}
		put_back();
		strcpy(cur_token, temp_token);
		token_type = temp_type;
	}
	proc_exp_relop(result);
}

template <class T>
typename FormulaParser<T>::rel_op_type FormulaParser<T>::lookup_relop(char *s)
{
	int i;
	for (i = 0; relop_name[i] && stricmp(relop_name[i], s) != 0; i++);
	if (!relop_name[i]) return (rel_op_type)-1;
	else return (rel_op_type)i;
}

template <class T>
void FormulaParser<T>::proc_exp_relop(T *result)
{
	T second;
	rel_op_type relop;

	proc_exp_2plus(result);
	if (token_type != Rel_Op) return;
	relop = lookup_relop(cur_token);
	get_token();
	proc_exp_2plus(&second);
	if (relop == LT)
	{
		if(*result < second)
			*result = "1";
		else
			*result = "0";
	}
	else if (relop == GT)
	{
		if(*result > second)
			*result = "1";
		else
			*result = "0";
	}
	else if (relop == LE)
	{
		if(*result <= second)
			*result = "1";
		else
			*result = "0";
	}
	else if (relop == GE)
	{
		if(*result >= second)
			*result = "1";
		else
			*result = "0";
	}
	else if (relop == EQ)
	{
		if(*result == second)
			*result = "1";
		else
			*result = "0";
	}
	else if (relop == NE)
	{
		if(*result != second)
			*result = "1";
		else
			*result = "0";
	}
}

template <class T>
void FormulaParser<T>::proc_exp_2plus(T *result)
{
	T second;
	int op;
	proc_exp_2mult(result);
	while (cur_token[0] == '+' || cur_token[0] == '-')
	{
		op = cur_token[0];
		get_token();
		proc_exp_2mult(&second);
		if (op == '+') *result = *result + second;
		else if (op == '-') *result = *result - second;
	}
}

template <class T>
void FormulaParser<T>::proc_exp_2mult(T *result)
{
	T second;
	int op;
	proc_exp_power(result);
	while (cur_token[0] == '*' || cur_token[0] == '/')
	{
		op = cur_token[0];
		get_token();
		proc_exp_power(&second);
		if (op == '*') *result = *result * second;
		else if (op == '/')
		{
			if (second == "0")
			{
				status = Divide_By_Zero;
				return;
			}
			*result = *result / second;
		}
	}
}

template <class T>
void FormulaParser<T>::proc_exp_power(T *result)
{
	T second;
	proc_exp_unary(result);
	while (cur_token[0] == '^')
	{
		get_token();
		proc_exp_unary(&second);
		*result = KfFunction::pow(*result, second);
	}
}
template <class T>
void FormulaParser<T>::proc_exp_unary(T *result)
{
	int op = 0;
	if (cur_token[0] == '+' || cur_token[0] == '-')
	{
		op = cur_token[0];
		get_token();
	}
	proc_exp_paren(result);
	if (op == '-') *result = -(*result);
}

template <class T>
void FormulaParser<T>::proc_exp_paren(T *result)
{
	if (cur_token[0] == '(')
	{
		get_token();
		proc_exp_assign(result);
		if (cur_token[0] != ')')
		{
			status = Rparen_Needed;
			return;
		}
		get_token();
	}
	else
		proc_exp_atom(result);
}

template <class T>
void FormulaParser<T>::proc_exp_atom(T *result)
{
	T arg;
//	char *endptr;
	char *temp_cur_pos;
	int i;
	int p;
	if (token_type == Function)
	{
		i = lookup_func(cur_token);
		if (!get_token())
		{
			status = Lparen_Needed;
			return;
		}
		if (strcmp(cur_token, "(") != 0)
		{
			status = Lparen_Needed;
			return;
		}
		temp_cur_pos = cur_pos;
		for (p = 0; *temp_cur_pos && (*temp_cur_pos != ')' || p != 0);
			temp_cur_pos++)
		{
			if (*temp_cur_pos == '(') p++;
			if (*temp_cur_pos == ')') p--;
		}
		if (*temp_cur_pos == NULL)
		{
			status = Rparen_Needed;
			return;
		}
		*temp_cur_pos = NULL;
		get_token();
		proc_exp_assign(&arg);
		*temp_cur_pos = ')';
		get_token(); get_token();
		*result = function[i](arg);
		return;
	}
	if (token_type == Variable)
	{
		*result = get_var(cur_token[0]);
		get_token();
		return;
	}
	if (token_type == Number)
	{
		*result = cur_token;
		get_token();
		return;
	}
	status = Syntax_Error;
}
#endif