#ifndef ___GLOBAL_H_
#define ___GLOBAL_H_
#include "FormelParser.h"

#endif