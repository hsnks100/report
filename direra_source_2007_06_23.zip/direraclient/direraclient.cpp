#include <winsock2.h>
#include <windows.h>
#include "resource.h"
#include "direraclient.h"
#include <commctrl.h>
#include <string.h>
#include "skel.h"
#include "sdk.h"
#include <Richedit.h>
#include <TCHAR.h>

/*

- gameCallback will be the function called when a new game starts
	game -> name of the selected game
	player -> player number (1-8). 0 for spectator.
	numplayers -> number of players in the game (1-8)

	Optional:
	- chatReceivedCallback will be the function called when a chat line text
	has been received. Set it to NULL if you don't need/want this callback.
	- clientDroppedCallback will be the function called when a client drops
	from the current game. Set it to NULL if you don't need/want this callback.
	- moreInfosCallback will be the function called when the user selects
	"More infos about this game..." in the game list context menu.
	Set it to NULL if you don't need/want this feature.

	*/

FILE* fp;
void debug_out(const TCHAR* fmt,...)
{
    static TCHAR buffer[256];
    va_list List;
    va_start(List, fmt);
    vswprintf_s(buffer, fmt, List);
    va_end(List);
    lstrcat(buffer, TEXT("\n")); // �ڵ� �ٹٲ��� ���� ���� ��� ������ �˴ϴ�
    //OutputDebugString("@MyApp : "); // �ٸ� �޽������ �����ϱ� ���ؼ�
    //OutputDebugString(buffer);
	MessageBox(0, buffer, TEXT(""), 0);
}

char netbuf[1024];
int packetsize=-1;
int offset=0;

HANDLE OurHandle;
SOCKET clntsock;
extern emulfos info;
char mygamename[100];
BOOL CALLBACK IPDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK RecentProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK AllServerProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK JoinServerProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK CreateRoomProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK InRoomMasterProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL WINAPI DllMain(HANDLE hDll,
					DWORD r,
					LPVOID h)
{
	OurHandle = hDll;
	if(r == DLL_PROCESS_ATTACH)
	{
		//MessageBox(0, TEXT("Dll�� ���μ����� map�˴ϴ�."), TEXT("�˸�"), 0);
	}
	else if(r == DLL_PROCESS_DETACH)
	{
		//MessageBox(0, TEXT("Dll�� ���μ������� �����˴ϴ�. "), TEXT("�˸�"), 0);
	}
	else if(r == DLL_THREAD_ATTACH)
	{
		//MessageBox(0, TEXT("�����尡 ���Ӱ� ���� �˴ϴ�. "), TEXT("�˸�"), 0);
	}
	else if(r == DLL_THREAD_DETACH)
	{
		//MessageBox(0, TEXT("�����尡 ���� �մϴ�. "), TEXT("�˸�"), 0);
	}
	return 1;
}

HWND hAllServer;
HWND hRecentServer;
HWND mainwindow;
HWND inroomwindow;
HWND joinwindow;
BOOL CALLBACK DlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{	
	if(iMessage == WM_SIZE)
	{
		return TRUE;
	}
	else if(iMessage == WM_NOTIFY)
	{
		if( ((LPNMHDR)lParam)->code == TCN_SELCHANGE)
		{
			if(TabCtrl_GetCurSel(GetDlgItem(hDlg, IDC_TAB1)) == 1)
			{
				RECT rt;
				GetClientRect(hDlg, &rt);
				TabCtrl_AdjustRect(GetDlgItem(hDlg, IDC_TAB1), FALSE, &rt); 
				ShowWindow(hAllServer, SW_HIDE);
				ShowWindow(hRecentServer, SW_SHOW);
				MoveWindow(hRecentServer, rt.left, rt.top, rt.right, rt.bottom, 1);
				//SetWindowPos(hRecentServer, HWND_TOP, rt.left, rt.top, rt.right, rt.bottom, SWP_NOSIZE );
			}
			else if(TabCtrl_GetCurSel(GetDlgItem(hDlg, IDC_TAB1)) == 0)
			{
				RECT rt;
				GetClientRect(hDlg, &rt);
				TabCtrl_AdjustRect(GetDlgItem(hDlg, IDC_TAB1), FALSE, &rt); 
				ShowWindow(hRecentServer, SW_HIDE);
				ShowWindow(hAllServer, SW_SHOW);
				MoveWindow(hAllServer, rt.left, rt.top, rt.right, rt.bottom, 1);
				//SetWindowPos(hAllServer, HWND_TOP, rt.left, rt.top, rt.right, rt.bottom, SWP_NOSIZE);
			}
		}

		return TRUE;
	}
	else if(iMessage == WM_INITDIALOG)
	{
		
		LoadLibrary(TEXT("Riched20.dll"));
		mainwindow = hDlg;
		hRecentServer = CreateDialog((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_RECENT), GetDlgItem(hDlg, IDC_TAB1), RecentProc);
		ShowWindow(hRecentServer, SW_SHOW);
		MoveWindow(hRecentServer, -1, -1, -1, -1, 0);
		hAllServer = CreateDialog((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_ALLSERVER), GetDlgItem(hDlg, IDC_TAB1), AllServerProc);
		ShowWindow(hAllServer, SW_SHOW);
		MoveWindow(hAllServer, -1, -1, -1, -1, 0);
		TCITEM tie;
		tie.mask = TCIF_TEXT;
		tie.iImage = -1;
		tie.pszText = TEXT("��缭��");

		TabCtrl_InsertItem(GetDlgItem(hDlg, IDC_TAB1), 0, &tie);
		tie.pszText = TEXT("�ֱ�");
		TabCtrl_InsertItem(GetDlgItem(hDlg, IDC_TAB1), 1, &tie);
		tie.pszText = TEXT("���ã��");
		TabCtrl_InsertItem(GetDlgItem(hDlg, IDC_TAB1), 2, &tie);
		tie.pszText = TEXT("�ɼ�");
		TabCtrl_InsertItem(GetDlgItem(hDlg, IDC_TAB1), 3, &tie);
		WSADATA wsadata;
		WSAStartup(MAKEWORD(2,2), &wsadata);


		//LAN(60fp/s);���(30fps);����(20fps);���(15fps);����(15fps);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_INSERTSTRING, 0, (LPARAM)TEXT("Bad(15fps)"));
		SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_INSERTSTRING, 0, (LPARAM)TEXT("Normal(15fps)"));
		SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_INSERTSTRING, 0, (LPARAM)TEXT("Good(20fps)"));
		SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_INSERTSTRING, 0, (LPARAM)TEXT("Exellent(30fps)"));
		SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_INSERTSTRING, 0, (LPARAM)TEXT("LAN(60fp/s)"));
		



		//SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_INSERTSTRING, 0, TEXT("LAN(60fp/s)"));
		SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_SETCURSEL, 0, 0);

		return TRUE;
	}
	else if(iMessage == WM_USER+1)
	{
		if(WSAGETSELECTEVENT(lParam) == FD_READ)
		{
			if(packetsize == -1)
			{
				recv(wParam, (char*)&packetsize, 4, 0);
				return TRUE;
			}
			else
			{
				//#
				int readbyte = recv(wParam, &netbuf[offset], packetsize-offset, 0);
				if(offset + readbyte != packetsize)
				{
					offset += readbyte;
					return TRUE;
				}
				else
				{
					packetsize = -1; // �� �޾Ҵ�
					offset = 0;
				}
			}
			char signal;
			memcpy(&signal, netbuf, 1);
			if(signal == 0x02)
			{
				DialogBox((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_JOINSERVER), hDlg, JoinServerProc);
			}
		}
		return TRUE;
	}
	else if(iMessage == WM_COMMAND)
	{
		if(wParam == IDOK || wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		else if(wParam == IDC_INPUTIP)
		{
			DialogBox((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_INPUTIP), hDlg, IPDlgProc);
		}
		return TRUE;
	}
	return FALSE;
}


BOOL CALLBACK IPDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_INITDIALOG)
	{
		SetWindowText(GetDlgItem(hDlg, IDC_SERVER), TEXT("58.79.25.118"));
		return TRUE;
	}
	else if(iMessage == WM_COMMAND)
	{
		if(wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		else if(wParam == IDC_CONNECT)
		{
			clntsock = socket(AF_INET, SOCK_STREAM, 0);

			//HOSTENT* host;
			char iptext[256];
			GetWindowTextA(GetDlgItem(hDlg, IDC_SERVER), iptext, sizeof(iptext)); 
			//host = gethostbyname(iptext);

			/*if(host == NULL)
			{
			unsigned long addr;
			addr = inet_addr(iptext);
			host = gethostbyaddr((char*)&addr, 4, AF_INET);
			}
			if(host == NULL)
			{
			MessageBox(hDlg, TEXT("ȣ��Ʈ ������ ã�����߽��ϴ�."), TEXT("�˸�"), 0);
			EndDialog(hDlg,0);
			//closesocket(clntsock);
			}
			*/	
			SOCKADDR_IN addr;
			//addr.sin_family = host->h_addrtype;
			memset(&addr,0,sizeof(addr));
			addr.sin_family = AF_INET;
			addr.sin_port = htons(27000);
			//addr.sin_addr.s_addr = *((unsigned int*)host->h_addr);
			addr.sin_addr.s_addr = inet_addr(iptext);
			if(connect(clntsock, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR)
			{
				if(WSAGetLastError() != WSAEWOULDBLOCK)
				{

					MessageBox(hDlg, TEXT("���ӿ���"), TEXT("asd"), 0);
					EndDialog(hDlg,0);
					return TRUE;
					//closesocket(clntsock);
				}
			}
			WSAAsyncSelect(clntsock, mainwindow, WM_USER+1, FD_READ | FD_CLOSE);
			//user loginuser;
			TCHAR username[20];
			//TCHAR username[256];
			GetWindowText(GetDlgItem(mainwindow, IDC_USERNAME), username, 20);
			unsigned char connection = (unsigned char)SendMessage(GetDlgItem(mainwindow, IDC_CONTYPE), CB_GETCURSEL, 0, 0);
			//loginuser.ping = -1;
			//loginuser.status = -1;
			//loginuser.username = username;
			char signal = 0x01; // ���� ��û �޽���
			int packetsize = sizeof(char)+sizeof(username)+sizeof(unsigned char);
			char senddata[sizeof(int)+sizeof(char)+sizeof(username)+sizeof(unsigned char)];
			memcpy(senddata, &packetsize, 4);
			memcpy(&senddata[4], &signal, 1);
			memcpy(&senddata[5], username, sizeof(username));
			memcpy(&senddata[5+sizeof(username)], &connection, sizeof(unsigned char));

			//#
			//writen(clntsock, senddata, sizeof(senddata));
			send(clntsock, senddata, sizeof(senddata), 0);
			EndDialog(hDlg,0);
		}
		return TRUE;
	}
	return FALSE;
}

BOOL CALLBACK RecentProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_COMMAND)
	{
		if(wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		return TRUE;
	}
	return FALSE;
}

BOOL CALLBACK AllServerProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_COMMAND)
	{
		if(wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		return TRUE;
	}
	return FALSE;
}

WNDPROC OldChatSubProc; 
LRESULT CALLBACK ChatSubProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_KEYDOWN)
	{
		if(wParam == VK_RETURN)
		{
			fp = fopen("log.txt", "a+t");
			fprintf(fp, "����Ű�Է�.\n");
			fclose(fp);
			TCHAR buf[100];
			GetWindowText(hWnd, buf, 100);
			if(lstrcmp(buf, TEXT("")) != 0)
				SendMessage(GetParent(hWnd), WM_COMMAND, IDC_PUBLICSEND, 0);
			fp = fopen("log.txt", "a+t");
			fprintf(fp, "ó����.\n\n");
			fclose(fp);
		}
		return FALSE;
	}
	return CallWindowProc(OldChatSubProc, hWnd,iMessage,wParam,lParam);  
}
BOOL CALLBACK JoinServerProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_INITDIALOG)
	{
		ListView_SetExtendedListViewStyle(GetDlgItem(hDlg, IDC_USERLIST), LVS_EX_FULLROWSELECT);
		ListView_SetExtendedListViewStyle(GetDlgItem(hDlg, IDC_ROOMLIST), LVS_EX_FULLROWSELECT);
		joinwindow = hDlg;
		OldChatSubProc = 
			(WNDPROC)SetWindowLong(GetDlgItem(hDlg, IDC_PUBLICCHAT), GWL_WNDPROC, (LONG)ChatSubProc);
		WSAAsyncSelect(clntsock, hDlg, WM_USER+1, FD_CLOSE | FD_READ);
		LVCOLUMN col;
		//col.
		memset(&col, 0, sizeof(col));
		col.mask = LVCF_FMT | LVCF_TEXT | LVCF_WIDTH|LVCF_SUBITEM;
		col.cx = 50;
		col.fmt = LVCFMT_CENTER;
		col.pszText = TEXT("�̸�");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_USERLIST), 0, &col);
		col.pszText = TEXT("��");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_USERLIST), 1, &col);
		col.pszText = TEXT("���ӹ��");
		col.cx = 100;
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_USERLIST), 2, &col);
		col.pszText = TEXT("����");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_USERLIST), 3, &col);
		col.pszText = TEXT("id");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_USERLIST), 4, &col);
		//���� ����, ���� ���� ���
		col.pszText = TEXT("����");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 0, &col);
		col.pszText = TEXT("���ķ�����");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 1, &col);
		col.pszText = TEXT("����");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 2, &col);
		col.pszText = TEXT("����");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 3, &col);
		col.pszText = TEXT("���");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 4, &col);
		col.pszText = TEXT("id");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_ROOMLIST), 5, &col);
		//0x05 �� ���� ���� ���� ��û.
		char _signal;
		_signal = 0x05; // ä�ø޼���
		int packetsize;
		packetsize = sizeof(char);
		char senddata[sizeof(int)+sizeof(char)];
		memcpy(senddata, &packetsize, 4);
		memcpy(&senddata[4], &_signal, 1);
		send(clntsock, senddata, sizeof(senddata), 0);
		_signal = 0x17;
		memcpy(&senddata[4], &_signal, 1);
		send(clntsock, senddata, sizeof(senddata), 0);
		return TRUE;
	}
	else if(iMessage == WM_USER+1)
	{
		if(WSAGETSELECTEVENT(lParam) == FD_READ)
		{
			//int packetsize;
			if(packetsize == -1)
			{
				recv(wParam, (char*)&packetsize, 4, 0);
				return TRUE;
			}
			else
			{
				//#
				int readbyte = recv(wParam, &netbuf[offset], packetsize-offset, 0);
				if(offset + readbyte != packetsize)
				{
					MessageBox(0, TEXT("����"), TEXT("����"), 0);
					offset += readbyte;
					return TRUE;
				}
				else
				{
					packetsize = -1; // �� �޾Ҵ�
					offset = 0;
				}
			}



			char signal;
			memcpy(&signal, netbuf, sizeof(char));
			if(signal == 0x04) // ä�� �޼����� �޾Ҵ� !!
			{
				TCHAR publicchat[100];
				TCHAR username[20];
				memcpy(username, &netbuf[sizeof(char)], sizeof(username));
				memcpy(publicchat, &netbuf[sizeof(char)+sizeof(username)], sizeof(publicchat));
				TCHAR* resulttext = new TCHAR[100+50]; // publicchat + username + @
				lstrcpy(resulttext, TEXT("<"));
				lstrcat(resulttext, username);
				lstrcat(resulttext, TEXT("> "));
				lstrcat(resulttext, publicchat);
				
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), EM_SETSEL, -1, -1);
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
					EM_REPLACESEL, 0, (LPARAM)resulttext ); // szText �߰�
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
					EM_REPLACESEL, 0, (LPARAM)TEXT("\n") ); // szText �߰�
				//MessageBox(0, resulttext, TEXT(""), 0);
				//SetWindowText(GetDlgItem(hDlg, IDC_PUBLICTEXT), resulttext);
				//EM_SETSEL
				//SendMessage(GetDlgItem(hDlg, IDC_PUBLICCHAT), EM_LINESCROLL, 
				//	0, SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), EM_GETLINECOUNT, 0, 0));
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), WM_VSCROLL, SB_BOTTOM, 0);
				
				delete [] resulttext;
			}
			else if(signal == 0x06) // ����� ������ ����
			{
				int users;
				memcpy(&users, &netbuf[sizeof(char)], sizeof(int));
				user* userlist = new user[users];
				//int* ids = new int[users];
				memcpy(userlist, &netbuf[sizeof(char)+sizeof(int)], sizeof(user)*users);
				//memcpy(ids, &netbuf[5 + sizeof(user)*users], sizeof(int)*users);
				LVITEM lvi;
				lvi.mask=LVIF_TEXT | LVIF_IMAGE;
				lvi.state=0;
				lvi.stateMask=0;
				lvi.iImage=0;

				for(int i=0; i<users; i++)
				{	
					
					lvi.iItem=i;
					
					lvi.iSubItem=0;
					lvi.pszText=(&userlist[i])->username;
					ListView_InsertItem(GetDlgItem(hDlg, IDC_USERLIST), &lvi);

					TCHAR tmp[10];
					wsprintf(tmp, TEXT("%d ms"), (&userlist[i])->ping);
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 1, tmp);
					if((&userlist[i])->connection == 0)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 2, TEXT("LAN(60fp/s"));
					}
					else if((&userlist[i])->connection == 1)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 2, TEXT("Exellent(30fps)"));
					}
					else if((&userlist[i])->connection == 2)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 2, TEXT("Good(20fps)"));
					}
					else if((&userlist[i])->connection == 3)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 2, TEXT("Normal(15fps)"));
					}
					else if((&userlist[i])->connection == 4)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 2, TEXT("Bad(15fps)"));
					}
					
				
					if((&userlist[i])->status == 1)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 3, TEXT("Idle"));
					}
					else if((&userlist[i])->status == 2)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 3, TEXT("Playing"));
					}
					
					wsprintf(tmp, TEXT("%d"), (&userlist[i])->id);
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						i, 4, tmp);
				}	
				//delete [] ids;
				delete [] userlist;
			}
			else if(signal == 0x08) // ���ο� ����ڰ� ����
			{
				user newuser;
				int id;
				memcpy(&newuser, &netbuf[1], sizeof(user));
				memcpy(&id, &netbuf[1+sizeof(user)], sizeof(int));
				LVITEM lvi;
				lvi.mask=LVIF_TEXT | LVIF_IMAGE;
				lvi.state=0;
				lvi.stateMask=0;
				lvi.iImage=0;
				lvi.iItem=0;
				lvi.iSubItem=0;
				lvi.pszText=newuser.username;
				ListView_InsertItem(GetDlgItem(hDlg, IDC_USERLIST), &lvi);

				TCHAR tmp[10];
				wsprintf(tmp, TEXT("%d ms"), newuser.ping);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
					0, 1, tmp);

				if(newuser.connection == 0)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 2, TEXT("LAN(60fp/s"));
				}
				else if(newuser.connection == 1)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 2, TEXT("Exellent(30fps)"));
				}
				else if(newuser.connection == 2)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 2, TEXT("Good(20fps)"));
				}
				else if(newuser.connection == 3)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 2, TEXT("Normal(15fps)"));
				}
				else if(newuser.connection == 4)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 2, TEXT("Bad(15fps)"));
				}

				if(newuser.status == 1)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 3, TEXT("Idle"));
				}
				else if(newuser.status == 2)
				{
					ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 3, TEXT("Playing"));
				}

				wsprintf(tmp, TEXT("%d"), id);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_USERLIST),
						0, 4, tmp);
				
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), EM_SETSEL, -1, -1);
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
					EM_REPLACESEL, 0, (LPARAM)TEXT("*") ); // szText �߰�
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
					EM_REPLACESEL, 0, (LPARAM)newuser.username ); // szText �߰�
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
					EM_REPLACESEL, 0, (LPARAM)TEXT("����\n") ); // szText �߰�
				SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), WM_VSCROLL, SB_BOTTOM, 0);
			}
			else if(signal == 0x10) // ������� Ŭ���̾�Ʈ ����
			{
				SOCKET id;
				memcpy(&id, &netbuf[1], sizeof(SOCKET));
				TCHAR idbuffer[10];
				LVITEM lvi;
				lvi.cchTextMax = 10;
				lvi.iSubItem = 4;
				lvi.pszText = idbuffer;
				int count = (int)SendMessage(GetDlgItem(hDlg, IDC_USERLIST), LVM_GETITEMCOUNT, 0, 0);
				for(int i=0; i<count; i++)
				{
					SendMessage(GetDlgItem(hDlg, IDC_USERLIST), LVM_GETITEMTEXT, i, (LPARAM)&lvi);
					SOCKET getid = _ttoi(lvi.pszText);
					if(id == getid)
					{
						TCHAR namebuffer[20];
						LVITEM lvi;
						lvi.cchTextMax = 20;
						lvi.iSubItem = 0;
						lvi.pszText = namebuffer;
						SendMessage(GetDlgItem(hDlg, IDC_USERLIST), LVM_GETITEMTEXT, i, (LPARAM)&lvi);
						ListView_DeleteItem(GetDlgItem(hDlg, IDC_USERLIST), i);
						SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), EM_SETSEL, -1, -1);
						SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
							EM_REPLACESEL, 0, (LPARAM)TEXT("*") ); // szText �߰�
						SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
							EM_REPLACESEL, 0, (LPARAM)lvi.pszText ); // szText �߰�
						SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT),
							EM_REPLACESEL, 0, (LPARAM)TEXT("����\n") ); // szText �߰�
						SendMessage(GetDlgItem(hDlg, IDC_PUBLICTEXT), WM_VSCROLL, SB_BOTTOM, 0);
						break;
					}
				}
			}
			else if(signal == 0x12)
			{
				char _signal = 0x13;
				int packetsize = sizeof(char);
				char senddata[sizeof(int)+sizeof(char)];
				memcpy(senddata, &packetsize, sizeof(int));
				memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
				send(clntsock, senddata, sizeof(senddata), 0);
				//SendMessage(GetDlgItem(
				HWND hwnd;
				hwnd = CreateDialog((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_INGAMEROOMMASTER), hDlg, InRoomMasterProc);
				ShowWindow(hwnd,SW_SHOW);
				MoveWindow(hwnd, 0, 300, 1000, 230, 0);
				ShowWindow(GetDlgItem(hDlg, IDC_ROOMLIST), SW_HIDE);
				

				//ShowWindow(GetDlgItem(hDlg, IDC_PUBLICTEXT), SW_HIDE);
			}
			else if(signal == 0x18)
			{
				int getid;
				memcpy(&getid, &netbuf[1], sizeof(int));
				int rows = ListView_GetItemCount(GetDlgItem(hDlg, IDC_ROOMLIST));
				for(int i=0; i<rows; i++)
				{
					TCHAR szGetid[10];
					ListView_GetItemText(GetDlgItem(hDlg, IDC_ROOMLIST), i, 5, szGetid, 10);
					if( _ttoi(szGetid) == getid )
					{
						ListView_DeleteItem(GetDlgItem(hDlg, IDC_ROOMLIST), i);
						break;
					}
				}
			}
			else if(signal == 0x20)
			{
				// userscount + roomid
				unsigned char userscount;
				int getid;
				memcpy(&userscount, &netbuf[1], sizeof(unsigned char));
				memcpy(&getid, &netbuf[1+sizeof(unsigned char)], sizeof(int));
				int rows = ListView_GetItemCount(GetDlgItem(hDlg, IDC_ROOMLIST));
				for(int i=0; i<rows; i++)
				{
					TCHAR szGetid[10];
					ListView_GetItemText(GetDlgItem(hDlg, IDC_ROOMLIST), i, 5, szGetid, 10);
					if( _ttoi(szGetid) == getid )
					{
						TCHAR szGetpeople[10];
						ListView_GetItemText(GetDlgItem(hDlg, IDC_ROOMLIST), i, 4, szGetpeople, 10);
						TCHAR* p = _tcstok(szGetpeople, TEXT(" / "));
						p = _tcstok(NULL, TEXT(" / "));
						TCHAR result[10];
						wsprintf(result, TEXT("%d / %s"), userscount, p);
						ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST), i, 4, result);
						//ListView_DeleteItem(GetDlgItem(hDlg, IDC_ROOMLIST), i);
						break;
					}
				}
			}
			else if(signal == 0x24)
			{
				//�� ���� ����� ������
			}
			else if(signal == 0x26)
			{
				// �ΰ��� ���̵� ����.
			}
			else if(signal == 0x16)
			{ // ���ο� �� ����
				// signal + appname + gamename + limituser + roomid + mastername
				char appname[40];
				char gamename[100];
				unsigned char limituser;
				int roomid;
				TCHAR mastername[20];
				memcpy(appname, &netbuf[1], sizeof(appname));
				memcpy(gamename, &netbuf[1+sizeof(appname)], sizeof(gamename));
				memcpy(&limituser, &netbuf[1+sizeof(appname)+sizeof(gamename)], sizeof(unsigned char));
				memcpy(&roomid, &netbuf[1+sizeof(appname)+sizeof(gamename)+sizeof(unsigned char)], 
					sizeof(int));
				memcpy(mastername, &netbuf[1+sizeof(appname)+sizeof(gamename)+sizeof(unsigned char)+sizeof(int)], 
					sizeof(mastername));
				LVITEM lvi;
				lvi.mask=LVIF_TEXT | LVIF_IMAGE;
				lvi.state=0;
				lvi.stateMask=0;
				lvi.iImage=0;
				lvi.iItem=0;
				lvi.iSubItem=0;
				TCHAR unicode[100];
				mbstowcs(unicode, gamename, 100);
				lvi.pszText = unicode;
				ListView_InsertItem(GetDlgItem(hDlg, IDC_ROOMLIST), &lvi);
		
				mbstowcs(unicode, appname, 100);
				//wsprintf(tmp, TEXT("%d ms"), newuser.ping);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
					0, 1, unicode);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
					0, 2, mastername);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
					0, 3, TEXT("Waiting"));
				TCHAR tmp[10];
				wsprintf(tmp, TEXT("1/%d"), limituser);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
					0, 4, tmp);
				wsprintf(tmp, TEXT("%d"), roomid);
				ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
					0, 5, tmp);
			}
			else if(signal == 0x22)
			{
				TCHAR newusername[20];
				unsigned short int ping;
				unsigned char contype;
				int id;
				memcpy(newusername, &netbuf[1], sizeof(newusername));
				memcpy(&ping, &netbuf[1+sizeof(newusername)], sizeof(short int));
				memcpy(&contype, &netbuf[1+sizeof(newusername)+sizeof(short int)], sizeof(char));
				memcpy(&id, &netbuf[1+sizeof(newusername)+sizeof(short int)+sizeof(char)], sizeof(int));
				
				LVITEM lvi;
				lvi.mask=LVIF_TEXT | LVIF_IMAGE;
				lvi.state=0;
				lvi.stateMask=0;
				lvi.iImage=0;
				lvi.iItem=0;
				lvi.iSubItem=0;
				//TCHAR unicode[100];
				//mbstowcs(unicode, gamename, 100);
				lvi.pszText = newusername;
				ListView_InsertItem(GetDlgItem(inroomwindow, IDC_GAMEUSER), &lvi);
		
		//		mbstowcs(unicode, appname, 100);
				//wsprintf(tmp, TEXT("%d ms"), newuser.ping);
				TCHAR tmp[10];
				wsprintf(tmp, TEXT("%d ms"), ping);
				ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
					0, 1, tmp);

				//LAN(60fp/s);���(30fps);����(20fps);���(15fps);����(15fps);
				if(contype == 0)
				{
					ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
						0, 2, TEXT("LAN(60fp/s"));
				}
				else if(contype == 1)
				{
					ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
						0, 2, TEXT("Exellent(30fps)"));
				}
				else if(contype == 2)
				{
					ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
						0, 2, TEXT("Good(20fps)"));
				}
				else if(contype == 3)
				{
					ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
						0, 2, TEXT("Normal(15fps)"));
				}
				else if(contype == 4)
				{
					ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
						0, 2, TEXT("Bad(15fps)"));
				}

				wsprintf(tmp, TEXT("%d"), id);
				ListView_SetItemText(GetDlgItem(inroomwindow, IDC_GAMEUSER),
						0, 3, tmp);
				SendMessage(GetDlgItem(inroomwindow, IDC_PRIVATETEXT), EM_SETSEL, -1, -1);
				SendMessage(GetDlgItem(inroomwindow, IDC_PRIVATETEXT),
					EM_REPLACESEL, 0, (LPARAM)TEXT("*") ); // szText �߰�
				SendMessage(GetDlgItem(inroomwindow, IDC_PRIVATETEXT),
					EM_REPLACESEL, 0, (LPARAM)newusername ); // szText �߰�
				SendMessage(GetDlgItem(inroomwindow, IDC_PRIVATETEXT),
					EM_REPLACESEL, 0, (LPARAM)TEXT("���� !\n") ); // szText �߰�
				SendMessage(GetDlgItem(inroomwindow, IDC_PRIVATETEXT), WM_VSCROLL, SB_BOTTOM, 0);
			}
			else if(signal == 0x14)
			{ // ��ü��� ����
				int len;
				memcpy(&len, &netbuf[1], sizeof(int));
				for(int i=0; i<len; i++)
				{
					gameroom gr;
					int roomid;
					TCHAR mastername[20];
					memcpy(&gr.gamename, &netbuf[1+sizeof(int) + (100+40+1+1+1+4+40)*i+0], 100);
					memcpy(&gr.appname, &netbuf[1+sizeof(int)+(100+40+1+1+1+4+40)*i+100], 40);
					memcpy(&gr.userscount, &netbuf[1+sizeof(int)+(100+40+1+1+1+4+40)*i+100+40], 1);
					memcpy(&gr.limituser, &netbuf[1+sizeof(int)+(100+40+1+1+1+4+40)*i+100+40+1], 1);
					memcpy(&gr.status, &netbuf[1+sizeof(int)+(100+40+1+1+1+4+40)*i+100+40+1+1], 1);
					memcpy(&roomid, &netbuf[1+sizeof(int) + (100+40+1+1+1+4+40)*i+100+40+1+1+1], 4);
					memcpy(mastername, &netbuf[1+sizeof(int)+100+40+1+1+1+4], sizeof(mastername));
					LVITEM lvi;
					lvi.mask=LVIF_TEXT | LVIF_IMAGE;
					lvi.state=0;
					lvi.stateMask=0;
					lvi.iImage=0;
					lvi.iItem=0;
					lvi.iSubItem=0;
					
					TCHAR unicode[100];
					//lstrcpy(unicode, TEXT("sdfs"));
					mbstowcs(unicode, gr.gamename, 100);
					lvi.pszText=unicode;
					ListView_InsertItem(GetDlgItem(hDlg, IDC_ROOMLIST), &lvi);

					TCHAR tmp[10];
					//wsprintf(tmp, TEXT("%d ms"), newuser.ping);
					mbstowcs(unicode, gr.appname, 40);
					ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
						0, 1, unicode);
					//MultiByteToWideChar(CP_ACP, 0, , strlen(gr.appname), unicode, 40);
					ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
						0, 2, mastername);
					if(gr.status == 0)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
						0, 3, TEXT("waiting"));
					}
					else if(gr.status == 1 || gr.status == 2)
					{
						ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
						0, 3, TEXT("playing"));
					}
					wsprintf(tmp, TEXT("%d / %d"), gr.userscount, gr.limituser);
					ListView_SetItemText(GetDlgItem(hDlg, IDC_ROOMLIST),
						0, 4, tmp);
				}
			}
		}
		else if(WSAGETSELECTEVENT(lParam) == FD_CLOSE)
		{
			shutdown(clntsock, SD_BOTH);
			closesocket(clntsock);
			MessageBox(hDlg, TEXT("�������� ������ ���������ϴ�."), TEXT("�˸�"), 0);
		}

		return TRUE;
	}
	else if(iMessage == WM_COMMAND)
	{
		if(wParam == IDCANCEL)
		{
			closesocket(clntsock);
			EndDialog(hDlg, 0);
		}
		else if(wParam == IDC_PUBLICSEND)
		{

			TCHAR publicchat[100];
			GetWindowText(GetDlgItem(hDlg, IDC_PUBLICCHAT), publicchat, 100);
			SetWindowText(GetDlgItem(hDlg, IDC_PUBLICCHAT), TEXT(""));
			char signal = 0x03; // ä�ø޼���
			int packetsize = sizeof(char)+sizeof(publicchat);
			char senddata[sizeof(int)+sizeof(char)+sizeof(publicchat)];
			memcpy(senddata, &packetsize, 4);
			memcpy(&senddata[4], &signal, 1);
			memcpy(&senddata[5], &publicchat, sizeof(publicchat));
			//#
			//writen(clntsock, senddata, sizeof(senddata));
			send(clntsock, senddata, sizeof(senddata), 0);
		}
		else if(wParam == IDC_CREATEROOM)
		{
			//char _signal = 0x11;
			//gameroom gr;
			//HWND h = CreateDialogA((HINSTANCE)OurHandle, MAKEINTRESOURCEA(IDD_CREATEROOM), hDlg, CreateRoomProc);
			//ShowWindow(h, SW_SHOW);
			DialogBox((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_CREATEROOM), hDlg, CreateRoomProc);
		}
		else if(wParam == IDC_JOINROOM)
		{

		}
		return TRUE;
	}
	return FALSE;
}





BOOL CALLBACK CreateRoomProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_INITDIALOG)
	{
		//info.
		for(std::vector<std::string>::iterator i=info.gamelist.begin();
			i != info.gamelist.end(); i++)
		{
			SendMessageA(GetDlgItem(hDlg, IDC_GAMELIST), LB_INSERTSTRING, 
				0, (LPARAM)i->c_str());
		}
		return TRUE;
	}
	else if(iMessage == WM_COMMAND)
	{
		if(wParam == IDC_CREATEBUTTON)
		{
			unsigned char lim = (unsigned char)GetDlgItemInt(hDlg, IDC_LIMITUSER, 0, 0);
			char appname[40];
			char gamename[100];
			strncpy(appname, info.appName.c_str(), 40);
			int sel = SendMessage(GetDlgItem(hDlg, IDC_GAMELIST), LB_GETCURSEL, 0, 0);
			SendMessageA(GetDlgItem(hDlg, IDC_GAMELIST), LB_GETTEXT, sel, (LPARAM)gamename);
			char _signal = 0x11;
			int packetsize = sizeof(char) + sizeof(appname) + sizeof(gamename) + sizeof(unsigned char);
			char senddata[sizeof(int) + sizeof(char) + sizeof(appname) + sizeof(gamename) + sizeof(unsigned char)];
			memcpy(senddata, &packetsize, sizeof(int));
			memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
			memcpy(&senddata[sizeof(int)+sizeof(char)], appname, sizeof(appname));
			memcpy(&senddata[sizeof(int)+sizeof(char)+sizeof(appname)], 
				gamename, sizeof(gamename));
			memcpy(&senddata[sizeof(int)+sizeof(char)+sizeof(appname)+sizeof(gamename)], 
				&lim, sizeof(unsigned char));
			send(clntsock, senddata, sizeof(senddata), 0);
			strcpy(mygamename, gamename);
			//ShowWindow(hDlg, SW_HIDE);
			EndDialog(hDlg, 0);
			//ShowWindow(hDlg, SW_HIDE);
		}
		else if(wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		return TRUE;
	}
	return FALSE;
}


BOOL CALLBACK InRoomMasterProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_INITDIALOG)
	{
		ListView_SetExtendedListViewStyle(GetDlgItem(hDlg, IDC_GAMEUSER), LVS_EX_FULLROWSELECT);
		inroomwindow = hDlg;
		//MessageBox(0, TEXT(""), TEXT(""), 0);
		SetDlgItemTextA(hDlg, IDC_DISPLAYGAMENAME, mygamename);
		LVCOLUMN col;
		//col.
		memset(&col, 0, sizeof(col));
		col.mask = LVCF_FMT | LVCF_TEXT | LVCF_WIDTH|LVCF_SUBITEM;
		col.cx = 50;
		col.fmt = LVCFMT_CENTER;
		col.pszText = TEXT("�̸�");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_GAMEUSER), 0, &col);
		col.pszText = TEXT("��");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_GAMEUSER), 1, &col);
		col.pszText = TEXT("���ӹ��");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_GAMEUSER), 2, &col);
		col.pszText = TEXT("id");
		ListView_InsertColumn(GetDlgItem(hDlg, IDC_GAMEUSER), 3, &col);
		/*TCHAR myname[20];
		TCHAR contype[20];
		GetWindowText(GetDlgItem(mainwindow, IDC_USERNAME), myname, 20);
		int sel = SendMessage(GetDlgItem(mainwindow, IDC_CONTYPE),
			CB_GETCURSEL, 0, 0);
		SendMessage(GetDlgItem(mainwindow, IDC_CONTYPE), CB_GETLBTEXT, sel, (LPARAM)contype);

		LVITEM lvi;
		lvi.mask=LVIF_TEXT | LVIF_IMAGE;
		lvi.state=0;
		lvi.stateMask=0;
		lvi.iImage=0;

		
		lvi.iItem=0;

		lvi.iSubItem=0;
		lvi.pszText=myname;
		ListView_InsertItem(GetDlgItem(hDlg, IDC_GAMEUSER), &lvi);
		ListView_SetItemText(GetDlgItem(hDlg, IDC_GAMEUSER),
			0, 1, TEXT("0 ms"));
		ListView_SetItemText(GetDlgItem(hDlg, IDC_GAMEUSER),
			0, 2, contype);*/
		return TRUE;
	}
	else if(iMessage == WM_COMMAND)
	{
		if(wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		else if(wParam == IDC_EXIT)
		{
			char _signal = 0x15;
			int packetsize = sizeof(char);
			char senddata[sizeof(int)+sizeof(char)];
			memcpy(senddata, &packetsize, sizeof(int));
			memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
			send(clntsock, senddata, sizeof(senddata), 0);
			ShowWindow(GetDlgItem(joinwindow, IDC_ROOMLIST), SW_SHOW);
			DestroyWindow(hDlg);
		}
		return TRUE;
	}
	return FALSE;
}

/*
���������� �� �۾� : ä��
�ؾߵɰ� : ���������� ���۰� ���� �� �г��� ǥ��.






Ŭ�� ���ӽÿ� �׾����




Ŭ�� �游��°� ���� ������ ���� ����.
*/