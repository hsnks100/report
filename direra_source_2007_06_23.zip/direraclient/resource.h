//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_DIALOG                      101
#define IDD_INPUTIP                     102
#define IDR_MENU1                       103
#define IDD_RECENT                      104
#define IDD_ALLSERVER                   105
#define IDD_JOINSERVER                  108
#define IDD_CREATEROOM                  109
#define IDD_INGAMEROOMMASTER            110
#define IDD_INGAMEROOM                  111
#define IDC_USERNAME                    1001
#define IDC_BUTTON1                     1002
#define IDC_CONNECT                     1002
#define IDC_SERVER                      1003
#define IDC_TAB1                        1005
#define IDC_RECENTLIST                  1007
#define IDC_COMBO1                      1008
#define IDC_COMTYPE                     1008
#define IDC_CONTYPE                     1008
#define IDC_BUTTON2                     1009
#define IDC_BUTTON4                     1011
#define IDC_BUTTON5                     1012
#define IDC_LIST1                       1013
#define IDC_INPUTIP                     1017
#define IDC_EDIT2                       1021
#define IDC_PUBLICCHAT                  1021
#define IDC_PUBLICTEXT                  1023
#define IDC_ROOMLIST                    1024
#define IDC_BUTTON3                     1025
#define IDC_CREATEROOM                  1025
#define IDC_PRIVATESEND                 1025
#define IDC_USERLIST                    1026
#define IDC_PUBLICSEND                  1027
#define IDC_JOINROOM                    1028
#define IDC_LIMITUSER                   1029
#define IDC_CREATEBUTTON                1030
#define IDC_GAMELIST                    1031
#define IDC_PRIVATECHAT                 1032
#define IDC_EXITBUTTON                  1033
#define IDC_PRIVATETEXT                 1034
#define IDC_STARTGAME                   1035
#define IDC_GAMEUSER                    1036
#define IDC_DISPLAYGAMENAME             1037
#define IDC_MASTEREXIT                  1038
#define IDC_EXIT                        1038
#define ID_40001                        40001
#define ID_40002                        40002
#define ID_40003                        40003
#define ID_CONNECT                      40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
