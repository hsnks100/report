#define KAILLERA_DLL
#include "sdk.h"
#include "resource.h"
#include "direraclient.h"

emulfos info;
int DLLEXP kailleraGetVersion(char *version)
{
	version = "0.1";
	return 1;
}

int DLLEXP kailleraInit()
{
	//MessageBox(0, TEXT("kailleraInit"), TEXT("aa"), 0);
	return 1;
}

int DLLEXP kailleraShutdown()
{
	//MessageBox(0, TEXT("kailleraShutdown"), TEXT("aa"), 0);
	return 1;
}

int DLLEXP kailleraSetInfos(kailleraInfos *infos)
{
	//MessageBox(0, TEXT("a"), TEXT("b"), 0);
	info.appName = infos->appName;
	int i=0;
	int j=0;
	//MessageBox(0, TEXT("a"), TEXT("bb"), 0);
	while(1)
	{
		if(infos->gameList[i] != NULL)
		{
			info.gamelist.push_back(&infos->gameList[i]);
			i += strlen(&infos->gameList[i])+1;
			j++;
		}
		else
		{
			break;
		}
	}
	info.chatReceivedCallback = infos->chatReceivedCallback;
	info.clientDroppedCallback = infos->clientDroppedCallback;
	info.gameCallback = infos->gameCallback;
	info.moreInfosCallback = infos->moreInfosCallback;
	//MessageBox(0, TEXT("a"), TEXT("bbb"), 0);
	//MessageBoxA(0, info.appName.c_str(), "aa", 0);
	//MessageBoxA(0, info.gamelist[1].c_str(), "aa", 0);
	//MessageBox(0, TEXT("kailleraSetInfos"), TEXT("aa"), 0);
	return 0;
}

int DLLEXP kailleraSelectServerDialog(HWND parent)
{
	//MessageBox(0, TEXT("kailleraSelectServerDialog"), TEXT("aa"), 0);
	DialogBox((HINSTANCE)OurHandle, MAKEINTRESOURCE(IDD_DIALOG), parent, DlgProc);
	
	return 1;
}

int DLLEXP kailleraModifyPlayValues(void *values, int size)
{
	MessageBox(0, TEXT("kailleraModifyPlayValues"), TEXT("aa"), 0);
	return 1;
}

/*
kailleraChatSend
Use this function to send a line of chat text during a game
*/
int DLLEXP kailleraChatSend(char *text)
{
	MessageBox(0, TEXT("kailleraChatSend"), TEXT("aa"), 0);
	return 1;
}
/*
kailleraEndGame:
Your emulation thread must call this method when the user stops the emulation
*/
int DLLEXP kailleraEndGame()
{
	MessageBox(0, TEXT("kailleraEndGame"), TEXT("aa"), 0);
	return 1;
}