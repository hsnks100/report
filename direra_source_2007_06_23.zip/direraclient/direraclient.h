#pragma once

#include <windows.h>
#include "resource.h"
#include <string>
#include <vector>
BOOL CALLBACK DlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
extern HANDLE OurHandle;
typedef struct
{
	std::string appName;
	std::vector<std::string> gamelist;

	int (WINAPI *gameCallback)(char *game, int player, int numplayers);

	void (WINAPI *chatReceivedCallback)(char *nick, char *text);
	void (WINAPI *clientDroppedCallback)(char *nick, int playernb);

	void (WINAPI *moreInfosCallback)(char *gamename);
}emulfos;

extern emulfos info;