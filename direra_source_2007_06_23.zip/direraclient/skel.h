#pragma once
#include <string>

struct user
{
	TCHAR username[20];
	unsigned short int ping;
	unsigned char status; // 1 : idle, 2 : play
	unsigned char connection; // 1 LAN ~ 6 BAD
	int id;
	bool operator==(const user& us) const
	{
		return id == us.id;
	}
};

struct gameroom
{
	char gamename[100];
	char appname[40];
	unsigned char userscount;
	unsigned char limituser;
	unsigned char status; // 0 : waiting, 1 : NetSync, 2 : Playing
	int id;
	std::vector<user> userlist;
	bool operator==(const gameroom& gr) const
	{
		return id == gr.id;
	}
};