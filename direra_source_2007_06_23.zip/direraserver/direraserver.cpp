#include <winsock2.h>
#include <windows.h>
#include "resource.h"
#include <vector>
#include <map>
#include <commctrl.h>
#include "skel.h"
#include <algorithm>
char netbuf[1024];
int packetsize=-1;
int offset=0;
SOCKET srvsock;
std::vector<user> clients;
std::vector<gameroom> rooms;


//std::map<int, char*> _netbuf;
//std::map<int, int> _recved;
//std::map<int, int> _packetsize;
int readn(int sock, void *vptr, int n)
{
	int nleft = 0, nread = 0;
	char *ptr;
	ptr = (char*)vptr;
	nleft = n;
	while(nleft > 0) 
	{
		if( (nread = recv(sock, ptr, nleft, 0)) == SOCKET_ERROR )  return (-1);
		if (nread == 0)    break;  // EOF
		nleft = nleft - nread;
		ptr = ptr + nread;
	}
	return (n - nleft);
}
int writen(int sock, const void *vptr, int n)
{
	int nleft = 0, nwritten = 0;
	const char *ptr;
	ptr = (char*)vptr;
	nleft = n;
	while(nleft > 0)
	{
		if( (nwritten = send(sock, ptr, nleft, 0)) == SOCKET_ERROR)   return (-1);
		nleft = nleft - nwritten;
		ptr = ptr + nwritten;
	}
	return (n);
}



//int test;
BOOL CALLBACK DlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
		  ,LPSTR lpszCmdParam,int nCmdShow)
{
	DialogBox(GetModuleHandle(0), MAKEINTRESOURCE(IDD_DIALOG), 0, DlgProc);
}
BOOL CALLBACK DlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	if(iMessage == WM_DESTROY)
	{
		WSACleanup();
		return TRUE;
	}
	else if(iMessage == WM_INITDIALOG)
	{
		WSADATA wsadata;
		if(WSAStartup(MAKEWORD(2,2), &wsadata))
		{
			MessageBox(hDlg, TEXT("WSAStartup����"), TEXT("WSAStartup����"), 0);
			WSACleanup();
			EndDialog(hDlg, 0);
		}
		srvsock = socket(AF_INET, SOCK_STREAM, 0);
		if(srvsock == INVALID_SOCKET)
		{
			WSACleanup();
			MessageBox(hDlg, TEXT("socket ����"), TEXT("e"), 0);
			EndDialog(hDlg, 0);
		}
		
		if(WSAAsyncSelect(srvsock, hDlg, WM_USER+1, FD_ACCEPT))
		{
			closesocket(srvsock);
			WSACleanup();
			MessageBox(hDlg, TEXT("�񵿱�ȭ ����"), TEXT("e"), 0);
			EndDialog(hDlg, 0);
		}

		SOCKADDR_IN srvaddr;
		srvaddr.sin_family = AF_INET;
		srvaddr.sin_port = htons(27000);
		srvaddr.sin_addr.s_addr = INADDR_ANY;
		if(bind(srvsock, (const sockaddr*)&srvaddr, sizeof(srvaddr)) == SOCKET_ERROR)
		{
			closesocket(srvsock);
			WSACleanup();
			MessageBox(hDlg, TEXT("bind ����"), TEXT("e"), 0);
			EndDialog(hDlg, 0);
		}
		if(listen(srvsock, 0) == SOCKET_ERROR)
		{
			closesocket(srvsock);
			WSACleanup();
			MessageBox(hDlg, TEXT("listen error!"), TEXT("e"), 0);
			EndDialog(hDlg, 0);
		}
		return TRUE;
	}
	else if(iMessage == WM_COMMAND)
	{
		if(wParam == IDOK || wParam == IDCANCEL)
		{
			EndDialog(hDlg,0);
		}
		return TRUE;
	}
	else if(iMessage == WM_USER+1)
	{
		if(WSAGETSELECTEVENT(lParam) == FD_CLOSE)
		{
			//TCHAR text[1000];
			//GetWindowText(GetDlgItem(hDlg, IDC_STATUS), text, 1000);
			//unsigned char* pip;
			//pip = (unsigned char*)&clients[(const int)wParam].ip;
			//wsprintf(text, TEXT("%s%s(%d.%d.%d.%d) ���Ӵ���\r\n"), text, clients[(const int)wParam].userinfo.username,
			//	pip[0], pip[1], pip[2], pip[3]);
			//SetWindowText(GetDlgItem(hDlg, IDC_STATUS), text);
			TCHAR tmp[20];
			wsprintf(tmp, TEXT("%d ���� ����\n"), wParam);
			SendMessage(GetDlgItem(hDlg, IDC_STATUS), EM_SETSEL, -1, -1);
			SendMessage(GetDlgItem(hDlg, IDC_STATUS),
				EM_REPLACESEL, 0, (LPARAM)tmp ); // szText �߰�
			SendMessage(GetDlgItem(hDlg, IDC_STATUS), WM_VSCROLL, SB_BOTTOM, 0);
			shutdown(wParam, SD_BOTH);
			closesocket(wParam);
			user comparetmp;
			comparetmp.id = wParam;
			clients.erase(find(clients.begin(), clients.end(), comparetmp));
			//clients.erase((const int)wParam);
			
			int packetsize = sizeof(char)+sizeof(SOCKET);
			char _signal = 0x10;
			SOCKET id = (SOCKET)wParam;			
			char senddata[sizeof(int)+sizeof(char)+sizeof(SOCKET)];
			memcpy(senddata, &packetsize, sizeof(int));
			memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
			memcpy(&senddata[sizeof(int)+sizeof(char)], &id, sizeof(SOCKET));
			for(std::vector<user>::iterator i=clients.begin(); 
				i != clients.end(); i++)
			{
				send(i->id, senddata, sizeof(senddata), 0);
			}
		}
		else if(WSAGETSELECTEVENT(lParam) == FD_READ)
		{
			if(packetsize == -1)
			{
				recv(wParam, (char*)&packetsize, 4, 0);
				return TRUE;
			}
			else
			{
				//#
				int readbyte = recv(wParam, &netbuf[offset], packetsize-offset, 0);
				if(offset + readbyte != packetsize)
				{
					offset += readbyte;
					return TRUE;
				}
				else
				{
					packetsize = -1; // �� �޾Ҵ�
					offset = 0;
				}
			}
			char signal;
			memcpy(&signal, netbuf, 1);

			if(signal == 0x01) // ���� ��û ����
			{
				//clients.push_back((user)&netbuf[1]
				TCHAR username[20];
				unsigned char connection;
				//memcpy(&clients[(const int)wParam].userinfo, &netbuf[1], sizeof(user));
				user newuser;
				memcpy(username, &netbuf[1], sizeof(username));
				memcpy(&connection, &netbuf[1+sizeof(username)], sizeof(unsigned char));
				newuser.connection = connection;
				newuser.id = (int)wParam;
				newuser.ping = 0;
				newuser.status = 1;
				lstrcpy(newuser.username, username);
				clients.push_back(newuser);
				TCHAR tmp[10];
				wsprintf(tmp, TEXT("%d ���ӿ�û\n"), wParam);
				SendMessage(GetDlgItem(hDlg, IDC_STATUS), EM_SETSEL, -1, -1);
				SendMessage(GetDlgItem(hDlg, IDC_STATUS),
					EM_REPLACESEL, 0, (LPARAM)tmp ); // szText �߰�
				SendMessage(GetDlgItem(hDlg, IDC_STATUS), WM_VSCROLL, SB_BOTTOM, 0);

				char _signal = 2;
				int packetsize = sizeof(char);
				char senddata[sizeof(int)+sizeof(char)];
				memcpy(senddata, &packetsize, 4);
				memcpy(&senddata[4], &_signal, 1);
				send(wParam, senddata, sizeof(senddata), 0);
				for(std::vector<user>::iterator i=clients.begin();
					clients.end() != i; i++)
				{
					if(i->id != wParam)
					{
						char _signal = 0x08;
						int packetsize = sizeof(char)+sizeof(user);
						char senddata[sizeof(int)+sizeof(char)+sizeof(user)];
						memcpy(senddata, &packetsize, sizeof(int));
						memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
						memcpy(&senddata[sizeof(int)+sizeof(char)], &newuser, sizeof(user));
						send(i->id, senddata, sizeof(senddata), 0);	
					}
				}
			}
			else if(signal == 0x03) // Ŭ���̾�Ʈ�߿� �Ѹ��� ����ħ 
			{
				//**//
				//std::find_if(
				TCHAR publicchat[100];
				TCHAR username[20];
				memcpy(publicchat, &netbuf[1], sizeof(publicchat));
				user comparetmp;
				comparetmp.id = wParam;
				lstrcpy(username, std::find(clients.begin(), clients.end(),  comparetmp)->username);
				char _signal = 0x04;
				int packetsize = sizeof(char)+sizeof(username)+sizeof(publicchat);
				char senddata[sizeof(int)+sizeof(char)+sizeof(username)+sizeof(publicchat)];
				memcpy(senddata, &packetsize, sizeof(int));
				memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
				memcpy(&senddata[sizeof(int)+sizeof(char)], username, sizeof(username));
				memcpy(&senddata[sizeof(int)+sizeof(char)+sizeof(username)], publicchat, 
					sizeof(publicchat));

				for(std::vector<user>::iterator i=clients.begin();
					clients.end() != i; i++)
				{
					send(i->id, senddata, sizeof(senddata), 0);	
				}
			}
			else if(signal == 0x05) // ����� ������ ��û�޾Ҵ�
			{
				std::vector<user> us = clients;
				//us 
				/*for(std::map<SOCKET, userinformation>::iterator i=clients.begin();
					clients.end() != i; i++)
				{					
					us.push_back(i->second.userinfo);
					id.push_back(i->first);
				}*/
				//			us ���Ϳ� ���� �����̳� ��Ÿ �۾� 
				char _signal = 0x06;
				int users = us.size();
				int packetsize = sizeof(char) + sizeof(int) + sizeof(user)*us.size();
				char* senddata = new char[sizeof(int)+sizeof(char) + sizeof(int) + sizeof(user)*us.size()];
				memcpy(senddata, &packetsize, sizeof(int));
				memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
				memcpy(&senddata[sizeof(int)+sizeof(char)], &users, sizeof(int));
				for(size_t i=0; i<us.size(); i++)
				{
					memcpy(&senddata[sizeof(int)+sizeof(char)+sizeof(int) + i*sizeof(user)], &us[i], sizeof(user));
					
				}
				//for(size_t i=0; i<us.size(); i++)
				//{
				//	memcpy(&senddata[9 + us.size()*sizeof(user) + i*sizeof(int)], &id[i], sizeof(int));	
				//}
				//memcpy(&senddata[9 + (i+1)*sizeof(user) + i*sizeof(int)], &id[i], sizeof(int));
				send(wParam, senddata, (int)(sizeof(int)+sizeof(char) + sizeof(int) + sizeof(user)*us.size()), 0);
				delete [] senddata;
			}
			else if(signal == 0x11)
			{
				//rooms.
				//roomobj.roomid++;
//				rooms.push_back(0);
				gameroom gr;
				memcpy(gr.appname, &netbuf[sizeof(char)], sizeof(gr.appname));
				memcpy(gr.gamename, &netbuf[sizeof(char)+sizeof(gr.appname)],
					sizeof(gr.gamename));
				memcpy(&gr.limituser, &netbuf[sizeof(char)+sizeof(gr.appname)+sizeof(gr.gamename)],
					sizeof(char));
				//user comparetmp;
				//comparetmp.id = wParam;
				gr.userlist.push_back(wParam);
				gr.userscount = 1;
				gr.status = 0;
				//std::vector<gameroom>::iterator endvalue = rooms.fron
				if( rooms.size() == 0)
					gr.id = 1;
				else
					gr.id = rooms.back().id+1;
				rooms.push_back(gr);
				
				char _signal = 0x12;
				char senddata[sizeof(int)+sizeof(char)];
				int packetsize = sizeof(char);
				memcpy(senddata, &packetsize, sizeof(int));
				memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
				send(wParam, senddata, sizeof(senddata), 0);
			}
			else if(signal == 0x13)
			{
				// signal + appname + gamename + limituser + roomid + mastername
				char _signal = 0x16;
				int packetsize = sizeof(char) + (140 + 1 + 4 + 40 + 4); 
				char senddata[sizeof(int) + sizeof(char) + (140 + 1 + 4 + 40 + 4)];
				memcpy(senddata, &packetsize, sizeof(int));
				memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
				memcpy(&senddata[sizeof(int)+sizeof(char)], rooms.back().appname, 40);
				memcpy(&senddata[sizeof(int)+sizeof(char)+40], rooms.back().gamename, 100);
				memcpy(&senddata[sizeof(int)+sizeof(char)+40+100], &rooms.back().limituser, 1);
				memcpy(&senddata[sizeof(int)+sizeof(char)+40+100+1], &rooms.back().id, sizeof(int));
				user comparetmp;
				comparetmp.id = rooms.back().userlist[0];
				memcpy(&senddata[sizeof(int)+sizeof(char)+40+100+1+sizeof(int)], 
					std::find(clients.begin(), clients.end(), comparetmp)->username, 40);
				for(std::vector<user>::iterator i=clients.begin();
					i != clients.end(); i++)
				{
					send(i->id, senddata, sizeof(senddata), 0);
				}

				//�̸�, ��, ���ӹ��, id ����
				_signal = 0x22;
				int packetsize2 = sizeof(char) + sizeof(TCHAR)*20 + sizeof(unsigned short int) + sizeof(char) + sizeof(int);
				char senddata2[sizeof(int) + sizeof(char) + sizeof(TCHAR)*20 + sizeof(short int) + sizeof(char) + sizeof(int)];
				memcpy(senddata2, &packetsize2, sizeof(int));
				memcpy(&senddata2[sizeof(int)], &_signal, sizeof(char));
				user comparetmp2;
				comparetmp2.id = wParam;
				memcpy(&senddata2[sizeof(int)+sizeof(char)], std::find(clients.begin(), clients.end(), comparetmp2)->username, 
					sizeof(TCHAR)*20);
				memcpy(&senddata2[sizeof(int)+sizeof(char)+sizeof(TCHAR)*20],
					&std::find(clients.begin(), clients.end(), comparetmp2)->ping, sizeof(short int));
				memcpy(&senddata2[sizeof(int)+sizeof(char)+sizeof(TCHAR)*20+sizeof(short int)],
					&std::find(clients.begin(), clients.end(), comparetmp2)->connection, sizeof(char));
				memcpy(&senddata2[sizeof(int)+sizeof(char)+sizeof(TCHAR)*20+sizeof(short int)+sizeof(char)],
					&wParam, sizeof(int));
				send(wParam, senddata2, sizeof(senddata2), 0);
			}
			else if(signal == 0x17)
			{ // ACK �� �ް� 
				// gamename, appname, userscount, limituser, status, id, ���� ���̵�

				/* ��ü ��� ���� */
				char _signal = 0x14;
				int packetsize = sizeof(char) + sizeof(int) + (140 + 3 + 4 + 40)*rooms.size();
				char* senddata = new char[sizeof(int)+sizeof(char) + sizeof(int) + (140 + 3 + 4 + 40)*rooms.size()];
				memcpy(senddata, &packetsize, sizeof(int));
				memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
				int tmpsize= rooms.size();
				memcpy(&senddata[sizeof(int)+sizeof(char)], &tmpsize, sizeof(int));
				int j=0;
				for(std::vector<gameroom>::iterator i=rooms.begin();
					i != rooms.end(); i++, j++)
				{
					memcpy(&senddata[4+1+4 + (140+3+4+40)*j], i->gamename, 
						100);
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100], i->appname,
						40);
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100+40], &i->userscount, 
						sizeof(unsigned char));
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100+40+1],
						&i->limituser, sizeof(unsigned char));
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100+40+1+1],
						&i->status, sizeof(unsigned char));
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100+40+1+1+1],
						&i->id, sizeof(int)); 

					/*gameroom comparetmp;
					comparetmp.id = i->id;
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100+40+1+1+1+4],
						std::find(rooms.begin(), rooms.end(), comparetmp)->userlist[0].c_str(), 
						40);*/ //���� ���̵� ã�Ƽ� �ű��� 0�� ° ����� �������� ����
					user comparetmp;
					comparetmp.id = wParam;
					memcpy(&senddata[4+1+4+ (140+3+4+40)*j + 100+40+1+1+1+4],
						std::find(clients.begin(), clients.end(), comparetmp)->username, 
						40);
//					MessageBox(0, roomobj.userlist[i->first][0].c_str(), TEXT(""), 0);
				}
				
				for(std::vector<user>::iterator i=clients.begin();
					i != clients.end(); i++)
				{
					send(i->id, senddata, sizeof(int)+sizeof(char) + sizeof(int) + (140 + 3 + 4 + 40)*rooms.size(), 0);
				}
				delete [] senddata;
				/* ��ü ��� ���۳� */
			}
			else if(signal == 0x15)
			{
				//�濡�� ����
				//if(�����̸�) else // �ƴϸ�
				//rooms ���� 
				//std::vector<gameroom>::iterator room;
				for(std::vector<gameroom>::iterator i=rooms.begin();
					i != rooms.end(); i++)
				{		
					if(std::find(i->userlist.begin(), i->userlist.end(), wParam) != i->userlist.end())
					{
						// ���⼭ i �� ���� ����� �ִ� �� !
						if(i->userlist[0] == wParam) // ����
						{
							char _signal = 0x18;
							int packetsize = sizeof(char) + sizeof(int);
							char senddata[sizeof(int) + sizeof(char) + sizeof(int)];
							memcpy(senddata, &packetsize, sizeof(int));
							memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
							memcpy(&senddata[sizeof(int)+sizeof(char)], &i->id, sizeof(int));
							for(std::vector<user>::iterator tmpi=clients.begin(); tmpi != clients.end(); tmpi++)
							{
								send(tmpi->id, senddata, sizeof(senddata), 0);
							}
							rooms.erase(i);
						}
						else
						{
							//�ϴ� ��ü������ �濡���� ���� ������ �Ѹ���
							//��ȿ� �ִ� ������Ը� ������������ �뺸
							i->userscount--;
							i->userlist.erase(std::find(i->userlist.begin(), i->userlist.end(), wParam));
							char _signal = 0x20;
							// _signal + userscount + roomid
							int packetsize = sizeof(char) + sizeof(char) + sizeof(int); 
							char senddata[sizeof(int) + sizeof(char) + sizeof(char) + sizeof(int)];
							memcpy(senddata, &packetsize, sizeof(int));
							memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
							memcpy(&senddata[sizeof(int)+sizeof(char)], &i->userscount, sizeof(char));
							memcpy(&senddata[sizeof(int)+sizeof(char)+sizeof(char)], &i->id, sizeof(int));
							for(std::vector<user>::iterator allloop=clients.begin(); 
								allloop != clients.end(); allloop++)
							{
								send(allloop->id, senddata, sizeof(senddata), 0);
							}
							/// �� ���� ��ü������ �濡 ���� ���� ����
							//ListView_Get
							//ListView_GetItemText(
							//wParam �� ���� ����� id, 
							
							
							for(std::vector<int>::iterator inroomuser=i->userlist.begin();
								inroomuser != i->userlist.end(); inroomuser++)
							{
								char _signal = 0x26;
								int packetsize = sizeof(char) + sizeof(int);
								char senddata[sizeof(int)+sizeof(char)+sizeof(int)];
								memcpy(senddata, &packetsize, sizeof(int));
								memcpy(&senddata[sizeof(int)], &_signal, sizeof(char));
								memcpy(&senddata[sizeof(int)+sizeof(char)], &wParam, sizeof(int));
								send(*inroomuser, senddata, sizeof(senddata), 0);
							}
							//send(
						}
						break;
					}
				}
				
				
//				std::find(rooms.begin(), rooms.end(), 
			}
		}
		else if(WSAGETSELECTEVENT(lParam) == FD_ACCEPT)
		{
			SOCKADDR client;
			int clientlen = sizeof(client);
			SOCKET socknum = accept(srvsock, &client, &clientlen);
			if(WSAAsyncSelect(socknum, hDlg, WM_USER+1, FD_READ | FD_CLOSE))
			{					
				MessageBox(hDlg, TEXT("�񵿱�ȭ ����"), TEXT("e"), 0);
			}
			
			//clients[socknum].ip = *(unsigned int*)&client.sa_data[2];
			//TCHAR text[1000];
			//GetWindowText(GetDlgItem(hDlg, IDC_STATUS), text, 1000);
			//wsprintf(text, TEXT("%s%d.%d.%d.%d ����\r\n"), text, (unsigned char)client.sa_data[2], 
			//	(unsigned char)client.sa_data[3], (unsigned char)client.sa_data[4], 
			//	(unsigned char)client.sa_data[5]);
			//SetWindowText(GetDlgItem(hDlg, IDC_STATUS), text);
			TCHAR tmp[10];
			wsprintf(tmp, TEXT("%d ����\n"), socknum);
			SendMessage(GetDlgItem(hDlg, IDC_STATUS), EM_SETSEL, -1, -1);
			SendMessage(GetDlgItem(hDlg, IDC_STATUS),
					EM_REPLACESEL, 0, (LPARAM)tmp ); // szText �߰�
			SendMessage(GetDlgItem(hDlg, IDC_STATUS), WM_VSCROLL, SB_BOTTOM, 0);
		}
		return TRUE;
	}	
	return FALSE;

	
}










/*





*/