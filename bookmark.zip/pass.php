<?

include "dbconn.php";


if($_GET[action] == "logout")
{
	SETCOOKIE("log", "");
	echo ("<script>location.href='view_list.php'</script>") ; 
}
if(crypt($_POST[password], "salt") == $admin_pass)
{
	SETCOOKIE("log", $admin_pass);
	echo ("<script>location.href='view_list.php'</script>") ; 
}
else
{
	echo '<meta http-equiv="content-type" content="text/html; charset=utf-8">';
	echo"
<form name=password action='$_SERVER[PHP_SELF]' method=post>
<input type='password' name='password'> <input type='submit'>
</form>
<script>document.password.password.focus(); </script>";

}


?>