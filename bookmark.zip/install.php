﻿

<form name=installform method=post action=install_ok.php>
호스트 이름 : <input type=text name=hostname><br />
유저 이름 : <input type=text name=username><br />
db 이름 : <input type=text name=dbname><br />
테이블 이름 : <input type=text name=tablename><br />
password : <input type=password name=pass><br />
<input type=submit value='설치하기'>

<script>document.installform.hostname.focus(); </script>