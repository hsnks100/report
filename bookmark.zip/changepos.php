﻿<?
include "dbconn.php";
if($HTTP_COOKIE_VARS[log] != $admin_pass)
{
	echo"<script>history.go(-1);</script>";
	exit;
}


// $movetype, $curpos 가 파라메터

if($_GET[movetype] == "down")
{
	$data = mysql_query("SELECT linkorder FROM $table_name where $curpos < linkorder order by linkorder limit 1", $connect );
	mysql_data_seek($data, 0);
	$bookmark = mysql_fetch_array( $data );
	
	$targetpos = $bookmark[linkorder];

	mysql_query("update $table_name set linkorder = 9999999 where linkorder=$targetpos", $connect) or die(mysql_error());
	mysql_query("update $table_name set linkorder = $targetpos where linkorder=$_GET[curpos]", $connect) or die(mysql_error());
	mysql_query("update $table_name set linkorder = $_GET[curpos] where linkorder=9999999", $connect) or die(mysql_error());

}
else if($_GET[movetype] == "up")
{
	$data = mysql_query("SELECT linkorder FROM $table_name where $curpos > linkorder order by linkorder desc limit 1", $connect ) or die(mysql_error());
	mysql_data_seek($data, 0);
	$bookmark = mysql_fetch_array( $data );
	
	$targetpos = $bookmark[linkorder];
	
	
	mysql_query("update $table_name set linkorder = 9999999 where linkorder=$targetpos", $connect) or die(mysql_error());
	mysql_query("update $table_name set linkorder = $targetpos where linkorder=$_GET[curpos]", $connect) or die(mysql_error());
	mysql_query("update $table_name set linkorder = $_GET[curpos] where linkorder=9999999", $connect) or die(mysql_error());
}
else if($_GET[movetype] == "mosttop")
{
	mysql_query("update $table_name set linkorder = linkorder+1", $connect) or die(mysql_error());
	mysql_query("update $table_name set linkorder = 0 where linkorder=$_GET[curpos]+1", $connect) or die(mysql_error());
}
else if($_GET[movetype] =="mostbottom")
{
	$data = mysql_query("SELECT linkorder FROM $table_name order by linkorder desc limit 1", $connect ) or die(mysql_error());
	mysql_data_seek($data, 0);
	$bookmark = mysql_fetch_array( $data );
	$targetpos = $bookmark[linkorder] + 1;
	mysql_query("update $table_name set linkorder = $targetpos where linkorder=$_GET[curpos]", $connect) or die(mysql_error());
}
?>

<?
echo "<script>location.href='view_list.php'</script>";

?>