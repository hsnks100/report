﻿<?
include "dbconn.php";
if($HTTP_COOKIE_VARS[log] != $admin_pass)
{
	echo"<script>history.go(-1);</script>";
	exit;
}


$query = "delete from $table_name where id=$_GET[no]";
mysql_query($query, $connect );

?>

echo ("<script>location.href='view_list.php'</script>") ; 