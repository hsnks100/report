﻿<meta http-equiv="content-type" content="text/html; charset=utf-8">
<center>
	
<table border=1>
	<tr><td>
		<form id="search" name="search" action="http://search.naver.com/search.naver" method="get" onsubmit="nvSetAction(this);" target=_blank>
		<select name="where" tabindex="1" onchange="search.frm.value='t2';">
		<option value="nexearch" selected="selected">통합검색</option>
		<option value="movie">영화</option>
		<option value="web">사이트</option>
		<option value="category">- 카테고리</option>
		<option value="site">- 사이트</option>
		<option value="webkr">웹문서</option>
		<option value="kin">지식iN</option>
		<option value="post">블로그</option>
		<option value="cafeblog">카페</option>
		<option value="cafe">- 카페명</option>
		<option value="article">- 카페글</option>
		<option value="image">이미지</option>
		<option value="video">동영상</option>
		<option value="dic">사전</option>
		<option value="100">- 백과사전</option>
		<option value="endic">- 영어사전</option>
		<option value="eedic">- 영영사전</option>
		<option value="krdic">- 국어사전</option>
		<option value="jpdic">- 일어사전</option>
		<option value="hanja">- 한자사전</option>
		<option value="terms">- 용어사전</option>
		<option value="news">뉴스</option>
		<option value="music">음악</option>
		<option value="doc">전문자료</option>
		<option value="local">지역</option>
		<option value="book">책</option>
		<option value="shop">쇼핑</option>
		<option value="mypc">내PC</option>
		</select>
		<input type="text" name="query" id="query" title="검색창" tabindex="2" class="tx" accesskey="s" size=30/>
		<input type="image" src="http://static.naver.com/w8/btn_sch.gif" name="" value="" alt="검색" class="btn" tabindex="3" onmouseover="this.src='http://static.naver.com/w8/btn_sch_over.gif'" onmousedown="this.src='http://static.naver.com/w8/btn_sch_down.gif'" onmouseout="this.src='http://static.naver.com/w8/btn_sch.gif'" />
		<input type="hidden" name="sm" value="top_sug" />
		<input type="hidden" name="frm" value="t1" />
		
		<div id="nautocomplete"></div>
	</form>
		</td>
		<td>
			<!-- Search Google -->

<form method=get action="http://www.google.co.kr/search">
<table bgcolor="#FFFFFF"><tr><td>
<a href="http://www.google.co.kr/">
<img src="http://www.google.co.kr/logos/Logo_40wht.gif" 
border="0" alt="Google" align="absmiddle"></a>
<input type=text name=q size=25 maxlength=255 value="">
<input type=hidden name=ie value=euc-kr>
<input type=hidden name=oe value=euc-kr>
<input type=hidden name=hl value=ko>
<input type=submit name=btnG value="Google 검색">
</td></tr></table>
</form>

<!-- Search Google -->
			</td>
			</tr>
			<tr>
				<td>
					<!-- 엠파스 검색창 -->
<table width="580" border="0" cellpadding="0" cellspacing="0" background="http://img.empas.com/search_tip_new/color_var07_02.gif">
<form name="search" method="get" onsubmit='SetAction(this);' target="_blank">
<tr>
<td width="11"><img src="http://img.empas.com/search_tip_new/color_var07_01.gif" width="5" height="38" border="0"></td>
<td width="117"><img src="http://img.empas.com/search_tip_new/logo_type04.gif" width="112" height="22" border="0" style="margin-top:4px"></td>
<td width="94"><select name="z" size="1" class="text/css" style="width:89px;height:20px;margin-bottom:-1px">
<option value='A' selected>통합검색</option><option value='H' >사전통합</option><option value='100' >백과사전</option><option value='J' >국어사전</option><option value='I' >영한사전</option><option value='EE' >영영사전</option>
</select></td>
<td width="353"><input type="text" name="q" class="text/css" style="width:294px;height:20px;margin-right:5px"><input type="image" src="http://img.empas.com/search_tip_new/search_but.gif" align="absmiddle" style="margin-right:3px"></td>
<td align="right"><img src="http://img.empas.com/search_tip_new/color_var07_03.gif" width="5" height="38" border="0"></td>
</tr>
</form>
</table>
<script>
function SetAction ( f ) {
v=f.z.value;
switch (v) {
case 'A'    : f.action='http://krd.empas.com/r/biq_ms_out/u=search.empas.com/search/all.html'; break;
case 'H' : f.action='http://search.empas.com/search/alldic.html'; break;
case '100' : f.action='http://search.empas.com/search/encdic.html'; break;
case 'I' : f.action='http://search.empas.com/search/endic.html'; break;
case 'J' : f.action='http://search.empas.com/search/krdic.html';  break;
case 'EE' : f.action='http://search.empas.com/search/eedic.html'; break;
}
}
</script>


<!-- 엠파스 검색창 -->
				</td>
				<td>
					<!-- 야후! 통합검색 시작 -->
<table width="300" border="0" cellspacing="1" cellpadding="3" bgcolor="#000000">
<tr> 
<td height="32" valign="bottom" align="center" bgcolor="#000000"><img src="http://img.yahoo.co.kr/spm/logo_yellow4.gif" width="89" height="23" align="absmiddle"> 
<b><font color="ffffff" size="2">통합 검색</font></b></td>
</tr>
<tr><td height="1"></td></tr>
<tr> 
<td bgcolor="eeeeee"> 
<font size=3>
<table width="300" border="0" cellspacing="0" cellpadding="2">
<form method="GET" action="http://kr.rd.yahoo.com/search/swin/all-radio2/*http://kr.search.yahoo.com/search" target="_blank">
<tr align="center"> 
<td colspan="3" height="40"> 
<input type="text" name="p" size="30">
<input type="image" src="http://img.yahoo.co.kr/spm/link_btn.gif" width="43" height="20" align="absmiddle"></td>
</tr>
<tr> 
<td width="105"> <font color="414141" size="2">
<input type="radio" name="jy" value="all" checked> 통합검색</font></td>
<td width="105"> <font color="414141" size="2"> 
<input type="radio" name="jy" value="news"> 뉴 스</font></td>
<td width="90"> <font color="414141" size="2">
<input type="radio" name="jy" value="image"> 이미지</font></td>
</tr>
<tr> 
<td> <font color="414141" size="2"> 
<input type="radio" name="jy" value="web"> 웹페이지</font></td>
<td> <font color="414141" size="2"> 
<input type="radio" name="jy" value="file"> 문서파일 </font></td>
<td> <font color="414141" size="2"> 
<input type="radio" name="jy" value="ency"> 백과사전</font></td>
</tr>
<tr> 
<td><font color="414141" size="2"> 
<input type="radio" name="jy" value="us"> 야후! 미국</font></td>
<td> </td>
<td> </td>
</tr>
<input type=hidden name=yid value=guest>
</form>
</table>
</font>
</td>
</tr>
</table><!--야후! 통합검색 끝 -->
				</td>
			</tr>
</table>


</center>
<?

include "dbconn.php";


echo "<font size=4>";
$query = "SELECT * FROM $table_name order by linkorder	";
$data = mysql_query( $query, $connect );
$total = mysql_affected_rows();


for($i = 0; $i < $total; $i++)
{
mysql_data_seek($data,$i);
$bookmark = mysql_fetch_array( $data );
echo "$bookmark[id] : $bookmark[linkorder] / ";
echo "<a href=\"$bookmark[url]\">";
if($bookmark[sitename]=="")
	echo "$bookmark[url]";
else
	echo "$bookmark[sitename]";
echo "</a>...<a href=\"$bookmark[url]\" target=_blank>[새창]</a>";
		if($HTTP_COOKIE_VARS[log] == $admin_pass)
		{
			echo " <a href=\"delete_ok.php?no=$bookmark[id]\">삭제</a>";
			echo "&nbsp;&nbsp;";
			if($total == 1)
				continue;
			if($i == 0)
				echo "<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=down\">↓</a>&nbsp;&nbsp;<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=mostbottom\">↓↓</a>";
			else if($i == $total - 1)
				echo "<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=up\">↑</a> &nbsp;&nbsp;<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=mosttop\">↑↑</a>";
			else
				echo "<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=up\">↑</a> <a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=down\">↓</a>&nbsp;&nbsp;<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=mosttop\">↑↑</a>&nbsp;&nbsp;<a href=\"changepos.php?curpos=$bookmark[linkorder]&movetype=mostbottom\">↓↓</a>";
		}
	echo '<br /><br />';
}


echo "</font>";
?>





</form>

<?
echo "<Br /><br />";
	if($HTTP_COOKIE_VARS[log] == $admin_pass)
	{
		echo "<form method=post action=write_ok.php>
사이트 이름 : <input type=text name=sitename><br />
URL : <input type=text name=url><br />
<input type=submit value='추가하기'>";

	echo '<Br /><br /><a href="pass.php?action=logout">로그아웃</a>';
	echo '<Br /><br /><a href="uninstall.php">북마크 프로그램 제거</a><br />';
	}
	else
	{
		echo '<a href="pass.php">관리자 모드</a>';
		
	}
	
?>
