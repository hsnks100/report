﻿<?
include "dbconn.php";
if($HTTP_COOKIE_VARS[log] != $admin_pass)
{
	echo"<script>history.go(-1);</script>";
	exit;
}

mysql_query("drop table $table_name", $connect);
unlink("config.php");

echo "테이블 제거가 완료되었습니다. 디렉토리안에 있는 파일을 지워주세요.";
?>