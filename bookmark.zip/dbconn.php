<?
  $data = file("config.php");
  
  
  $host_name= $data[1]; 
  $user_name= $data[2];    
  $db_name=$data[3];      
  $table_name=$data[4];
  $db_password=$data[5];
  $admin_pass = $data[6];
  
  $host_name = trim($host_name);
  $user_name = trim($user_name);
  $db_name = trim($db_name);
  $table_name = trim($table_name);
  $db_password = trim($db_password);
	$admin_pass = trim($admin_pass);
  $connect = mysql_connect($host_name, $user_name, $db_password) or die(mysql_error());
  mysql_select_db($db_name, $connect ) or die(mysql_error());
  

?>