﻿<?
if(@file("config.php") == 0)
{
	
	$file = fopen("config.php", "w");
	fwrite($file, "<?\n$_POST[hostname]\n$_POST[username]\n$_POST[dbname]\n$_POST[tablename]\n$_POST[pass]\n");
	fclose($file);
	
	include "dbconn.php";
	
	
	$que = "CREATE TABLE $table_name (
	                                      id int NOT NULL auto_increment,
	                                      sitename text,
	                                      url text not null,
	                                      linkorder int,
	                                      PRIMARY KEY (id)
	)";
	
	mysql_query( $que, $connect ) or die(mysql_error());
	
	echo "테이블이 생성되었습니다.\n";
	echo '<a href="install2.php">다음</a>';
}
else
{
	echo "이미 설치가 되었습니다.";
}
?>