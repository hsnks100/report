﻿<?
include "dbconn.php";
if($HTTP_COOKIE_VARS[log] != $admin_pass)
{
	echo"<script>history.go(-1);</script>";
	exit;
}

if($_POST[url] == "")
{
	echo"<script>history.go(-1);</script>";
	exit;
}

$_POST[sitename]=addslashes($_POST[sitename]);
$_POST[url] = addslashes($_POST[url]);


$data = mysql_query("SELECT linkorder FROM $table_name order by linkorder desc limit 1", $connect );

if(mysql_affected_rows() >= 1)
{
mysql_data_seek($data, 0);
$bookmark = mysql_fetch_array( $data );

mysql_query("insert into $table_name (url, sitename, linkorder)
                values ('$_POST[url]','$_POST[sitename]', $bookmark[linkorder]+1)", $connect)
   or die(mysql_error());
}
else
{
	mysql_query("insert into $table_name (url, sitename, linkorder)
                values ('$_POST[url]','$_POST[sitename]', '0')", $connect);
}
echo ("<script>location.href='view_list.php'</script>") ; 

?>